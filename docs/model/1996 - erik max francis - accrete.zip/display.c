void display_system()
{
     planet_pointer node1; 
     int counter; 
     char word[(10)+1]; 

     printf("SYSTEM CHARACTERISTICS\n");
     printf("Mass of central star [solar]: %.2lf\n", stellar_mass_ratio);
     printf("Luminosity of central star [solar]: %.2lf\n",stellar_luminosity_ratio);
     printf("Total main sequence lifetime [Gy]: %.2lf\n", (main_seq_life / 1.0E9));
     printf("Current age of stellar system [Gy]: %.2lf\n",(age / 1.0E9));
     printf("Radius of habitable ecosphere [au]: %.2lf\n",r_ecosphere);
     printf("\n");
     node1 = planet_head;
     counter = 1;
     while (node1 != NULL)
     {
	  printf("Planet %d",counter);
	  if (node1->gas_giant)
	       printf(" jovian");
	  if (node1->resonant_period)
	       printf(" resonant");
     if (!node1->gas_giant && node1->greenhouse_effect && node1->surface_pressure > 0.)
          printf(" greenhouse");
      printf(":\n");
	  printf("    Semimajor axis [au]: %.2lf\n",node1->a);
	  printf("    Orbital eccentricity: %.2lf\n",node1->e);
	  printf("    Mass [earth]: %.2lf\n",node1->mass * EARTH_MASSES_PER_SOLAR_MASS);
	  printf("    Equatorial radius [km]: %.0lf\n",node1->radius);
	  printf("    Average density [g/cm^3]: %.2lf\n",node1->density);
	  printf("    Escape velocity from surface [km/s]: %.1lf\n",node1->escape_velocity / CM_PER_KM);
	  printf("    Smallest molecular weight retained [u]: %.1lf\n",node1->molecule_weight);
/*	  printf("    Surface acceleration [cm/s^2]: %.2lf\n",node1->surface_accel); */
	  if (!(node1->gas_giant))
	  {
	       printf("    Surface gravity [gee]: %.2lf\n",node1->surface_grav);
	       printf("    Boiling point of water [K]: %.0lf\n",(node1->boil_point));
	       printf("    Surface pressure [atm]: %.1lf\n",(node1->surface_pressure / 1000.0));
        /* if ((node1->greenhouse_effect) && (node1->surface_pressure > 0.0))
		    printf("      RUNAWAY GREENHOUSE EFFECT\n");
	       else 
		    printf("\n"); */
	       printf("    Surface temperature [K]: %.1lf\n",(node1->surface_temp));
	       printf("    Hydrosphere coverage [%%]: %.1lf\n",(node1->hydrosphere * 100.0));
	       printf("    Cloud coverage [%%]: %.1lf\n",(node1->cloud_cover * 100));
	       printf("    Ice coverage [%%]: %.1lf\n",(node1->ice_cover * 100));
	  }
	  printf("    Axial tilt [deg]: %d\n",node1->axial_tilt);
	  printf("    Planetary albedo: %.2lf\n",node1->albedo);
	  printf("    Length of year [earth]: %.1lf\n",node1->orbital_period/DAYS_IN_A_YEAR);
	  printf("    Length of day [earth]: %.1lf\n",node1->day/24.);
	  counter++;
	  node1 = node1->next_planet;
     }
}
