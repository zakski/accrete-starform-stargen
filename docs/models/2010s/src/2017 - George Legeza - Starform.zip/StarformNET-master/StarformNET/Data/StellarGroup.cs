﻿namespace DLS.StarformNET.Data
{
    using System.Collections.Generic;

    public class StellarGroup
    {
        public int Seed;
        public SystemGenerationOptions GenOptions;
        public List<StellarSystem> Systems;
    }
}
