namespace DLS.StarformNET.Data
{
    public interface IPlanetTrait
    {
        string Name { get; }
        string Description { get; }
    }
}
