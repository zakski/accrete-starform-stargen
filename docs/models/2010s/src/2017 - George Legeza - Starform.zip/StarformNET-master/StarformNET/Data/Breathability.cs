namespace DLS.StarformNET.Data
{
    public enum Breathability
    {
        None,
        Breathable,
        Unbreathable,
        Poisonous

    }
}