namespace DLS.StarformNET.Data
{
    public enum PlanetType
    {
        Unknown,
        Barren,
        Venusian,
        Terrestrial,
        GasGiant,
        Martian,
        Water,
        Ice,
        SubGasGiant,
        SubSubGasGiant,
        Asteroids
    }
}
