Welcome to StarGen. 

StarGen is a a random solar system generator, derived from the work of a
great number of people over the past three dozen years. (See Credits.txt for
details.) It's called StarGen because there are already enough versions that
call themselves Accrete/Starform to be confusing. 

StarGen used to run on Windows and Macintosh but since I (Graham Reeds) took 
over stewardship of the code, I decided to ditch the Mac side of things as
I don't have a Mac to develop and test on. If someone else would like to 
contribute then fork and push me patches.