// TestStarGenDemo.cpp : Defines the entry point for the console application.
//

#include "UnitTest++.h"

int main(int argc, char* argv[])
{
	return UnitTest::RunAllTests();
}

