long double random_number(long double, long double);
long double about(long double, long double);
long double random_eccentricity(void);
