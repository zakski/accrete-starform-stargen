#pragma once

namespace StarGen
{
	class StarGen
	{
	public:
		StarGen();
		~StarGen();

		int operator()();

	private:
	};
}
