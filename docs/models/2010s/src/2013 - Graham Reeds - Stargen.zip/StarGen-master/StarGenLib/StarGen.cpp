#include "StarGen.h"

namespace StarGen
{
	StarGen::StarGen()
	{
	}

	StarGen::~StarGen()
	{
	}

	int StarGen::operator()() 
	{
		return 0; 
	}
}