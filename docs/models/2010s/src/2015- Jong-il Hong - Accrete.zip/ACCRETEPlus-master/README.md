[![Appveyor Build status](https://ci.appveyor.com/api/projects/status/github/donggas90/accreteplus?branch=master&svg=true)](https://ci.appveyor.com/project/donggas90/accreteplus)

# ACCRETEPlus

ACCRETE is a Stellar System Generation Program.
It is based on a paper that Dole, Stephen H. "Formation of Planetary Systems by Aggregation a Computer Simulation".

The first writer was Matt Burdick and Chris Croughton had modified.
Then the Starform had expanded.
In 2011, Daniel Lyons had been expanded.
Currently, I have moved and modified in this repository and renamed to ACCRETEPlus.
It means, C++ version of ACCRETE.

[Here](https://raw.githubusercontent.com/donggas90/ACCRETEPlus/master/EXAMPLE.txt) is an Example Output.

Please, see the [Wiki](https://github.com/donggas90/ACCRETEPlus/wiki) for more informations.


Authors
=====
* 1969 Matt Burdick & Chris Croughton
* 2011 Daniel Lyons
* 2015 Jong-il Hong


Copyrights
=====
* Copyright (c) 2011 Daniel Lyons
* Copyright (c) 2015 Jong-il Hong
