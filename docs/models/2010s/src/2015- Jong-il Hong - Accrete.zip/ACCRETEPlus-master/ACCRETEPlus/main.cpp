#include <stdio.h>
#include <stdlib.h>

#include <vector>
#include <algorithm>

#include "accreteAccrete.h"
#include "accreteGensys.h"
#include "accreteDisplay.h"

using namespace accrete;

void MyPrintf(const char* Format, ...)
{
	va_list ap;
	_crt_va_start(ap, Format);
	::vprintf(Format, ap);
	_crt_va_end(ap);
}
double MyRandom(double Min, double Max)
{
	unsigned long r = ::rand();
	double rr = (double)r / ((double)RAND_MAX);
	double range = Max - Min;
	return rr * range + Min;
}

std::vector<void*> MemCheck;
void* MyMalloc(size_t Size)
{
	void* Mem = ::malloc(Size);
	MemCheck.push_back(Mem);
	return Mem;
}
void MyFree(void* Ptr)
{
	MemCheck.erase(std::remove(MemCheck.begin(), MemCheck.end(), Ptr), MemCheck.end());
	::free(Ptr);
}

int main(int argc, char **argv)
{
	// Optional, Bind Custom Printf Function.
	GPrintfPtr = MyPrintf;
	// Optional, Bind Custom Random Function.
	GRandomPtr = MyRandom;
	// Optional, Bind Custom Malloc Function.
	GMallocPtr = MyMalloc;
	// Optional, Bind Custom Free Function.
	GFreePtr = MyFree;

	// Generate Moons.
	args.make_moon = true;
	// Enable Detailed Print.
	args.verbose = true;

	// Seed for rand() in MyRandom().
	srand(123);

	// Generate a Stellar System.
	SStellarSystem* System = generate_stellar_system();
	display_system(System);
	// Must Call this Function to Collect Memories.
	free_stellar_system(System);

	const register int MemStat = (int)MemCheck.size();
	if (MemStat > 0)
	{
		return MemStat;
	}
	return 0;
}
