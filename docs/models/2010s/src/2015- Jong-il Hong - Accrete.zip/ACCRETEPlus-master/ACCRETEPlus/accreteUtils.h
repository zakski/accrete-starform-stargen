#pragma once

namespace accrete
{
	double DefaultRandom(double Min, double Max);

	typedef double(*RandomFunc)(double Min, double Max);
	extern RandomFunc GRandomPtr;

	double random_number(double inner, double outer);
	double about(double value, double variation);
	double random_eccentricity(void);

}
