#pragma once

#include "accreteConst.h"
#include "accreteStructs.h"
#include "accreteUtils.h"

namespace accrete
{
	extern SFlags args;

	struct SStellarSystem
	{
		double        star_mass_r;
		double        star_lum_r;
		double        star_radius_r;
		double        star_temp;
		double        main_seq_life;
		double        star_age;
		double        r_ecosphere;
		double        r_greenhouse;
		char          star_class[17];
		bool           resonance;
		SPlanet*       first_planet;
	};

	SStellarSystem* generate_stellar_system(double star_mass = 1.0);
	void free_stellar_system(SStellarSystem* system);
}
