#pragma once

#include <cstring>

#include "accreteStructs.h"
#include "accreteUtils.h"
#include "accreteGensys.h"

namespace accrete
{
	
	void* DefaultMalloc(size_t Size);
	typedef void*(*MallocFunc)(size_t Size);
	extern MallocFunc GMallocPtr;

	void DefaultFree(void* Ptr);
	typedef void(*FreeFunc)(void* Ptr);
	extern FreeFunc GFreePtr;


	extern SFlags args;

	struct SDust
	{
		double      inner_edge;
		double      outer_edge;
		bool        has_dust;
		bool        has_gas;
		SDust* next_band;
	};

	struct SAccretion
	{
		/* A few variables global to the entire program:                */
		SPlanet* planet_head;

		/* Now for some variables global to the accretion process:      */
		int         dust_left;
		double      r_inner;
		double      r_outer;
		double      reduced_mass;
		double      dust_density;
		double      cloud_eccen;
		SDust* dust_head;
	};


	// If these are our entry points, they should probably look more like
	// entry points than random functions. -DKL

	double stellar_dust_limit(double star_mass_r);

	SPlanet* distribute_planetary_masses(
		SStellarSystem* system,
		double inner_dust,
		double outer_dust);

	SPlanet* do_dist_moon_masses(
		double planetary_mass,
		double plan_radius);

}

