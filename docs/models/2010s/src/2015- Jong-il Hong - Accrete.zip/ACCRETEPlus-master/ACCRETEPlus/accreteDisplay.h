#pragma once

#include "accreteStructs.h"
#include "accreteGensys.h"

// there's an implicit dependency between these and the arguments
// struct. -DKL

namespace accrete
{
	void DefaultPrintf(const char* Format, ...);

	typedef void(*PrintfFunc)(const char* Format, ...);
	extern PrintfFunc GPrintfPtr;

	void display_system(SStellarSystem* system);

}

#define ACCRETE_VERBOSE_PRINTF(Format, ...) if (accrete::args.verbose) { accrete::GPrintfPtr(Format, __VA_ARGS__); }