#pragma once

#define ACCRETE_PI                      (3.1415926536)
#define ACCRETE_RADIANS_PER_ROTATION    (2.0 * ACCRETE_PI)
#define ACCRETE_ECCENTRICITY_COEFF      (0.077)         /* Dole's was 0.077         */
#define ACCRETE_PROTOPLANET_MASS        (1.0E-15)       /* Units of solar masses    */
#define ACCRETE_CHANGE_IN_EARTH_ANG_VEL (-1.3E-15)      /* Units of radians/sec/year */
#define ACCRETE_SOLAR_MASS_IN_GRAMS     (1.989E33)      /* Units of grams           */
#define ACCRETE_SOLAR_RADIUS_IN_METRES  (6.96e8)        /* units of metres          */
#define ACCRETE_EARTH_MASS_IN_GRAMS     (5.977E27)      /* Units of grams           */
#define ACCRETE_EARTH_RADIUS            (6.378E8)       /* Units of cm                */
#define ACCRETE_EARTH_DENSITY           (5.52)  /* Units of g/cc      */
#define ACCRETE_KM_EARTH_RADIUS         (6378.0)        /* Units of km              */
#define ACCRETE_EARTH_ACCELERATION      (981.0)         /* Units of cm/sec2         */
#define ACCRETE_EARTH_AXIAL_TILT        (23.4)  /* Units of degrees         */
#define ACCRETE_EARTH_EXOSPHERE_TEMP    (1273.0)        /* Units of degrees Kelvin  */
#define ACCRETE_SUN_MASS_IN_EARTH_MASSES (332775.64)
#define ACCRETE_EARTH_EFFECTIVE_TEMP    (255.0)         /* Units of degrees Kelvin  */
#define ACCRETE_EARTH_ALBEDO            (0.3)
#define ACCRETE_CLOUD_COVERAGE_FACTOR   (1.839E-8)      /* Km2/kg                   */
#define ACCRETE_EARTH_WATER_MASS_PER_AREA       (3.83E15)       /* grams per square km     */
#define ACCRETE_EARTH_SURF_PRES_IN_MILLIBARS     (1000.0)
#define ACCRETE_EARTH_CONVECTION_FACTOR (0.43)  /* from Hart, eq.20         */
#define ACCRETE_FREEZING_POINT_OF_WATER (273.0)         /* Units of degrees Kelvin  */
#define ACCRETE_DAYS_IN_A_YEAR          (365.256)       /* Earth days per Earth year */
                                                /*         gas_retention_threshold = 6.0; *//* ratio of esc vel to RMS vel */
#define ACCRETE_GAS_RETENTION_THRESHOLD (5.0)   /* ratio of esc vel to RMS vel */
#define ACCRETE_GAS_GIANT_ALBEDO        (0.5)   /* albedo of a gas giant    */
#define ACCRETE_CLOUD_ALBEDO            (0.52)
#define ACCRETE_AIRLESS_ROCKY_ALBEDO    (0.07)
#define ACCRETE_ROCKY_ALBEDO            (0.15)
#define ACCRETE_WATER_ALBEDO            (0.04)
#define ACCRETE_AIRLESS_ICE_ALBEDO      (0.5)
#define ACCRETE_ICE_ALBEDO              (0.7)
#define ACCRETE_SECONDS_PER_HOUR        (3600.0)
#define ACCRETE_CM_PER_AU               (1.495978707E13)        /* number of cm in an AU    */
#define ACCRETE_CM_PER_KM               (1.0E5)         /* number of cm in a km     */
#define ACCRETE_KM_PER_AU               (ACCRETE_CM_PER_AU / ACCRETE_CM_PER_KM)
#define ACCRETE_CM_PER_METER            (100.0)
#define ACCRETE_MILLIBARS_PER_BAR       (1000.0)
#define ACCRETE_KELVIN_CELCIUS_DIFFERENCE       (273.0)
#define ACCRETE_GRAV_CONSTANT           (6.672E-8)      /* units of dyne cm2/gram2  */
#define ACCRETE_GREENHOUSE_EFFECT_CONST (0.93)  /* affects inner radius..   */
#define ACCRETE_MOLAR_GAS_CONST         (8314.41)       /* units: g*m2/(sec2*K*mol) */
#define ACCRETE_K                       (50.0)  /* K = gas/dust ratio       */
#define ACCRETE_B                       (1.2E-5)        /* Used in Crit_mass calc   */
#define ACCRETE_DUST_DENSITY_COEFF      (2.0E-3)        /* A in Dole's paper        */
#define ACCRETE_ALPHA                   (5.0)   /* Used in density calcs    */
#define ACCRETE_N                       (3.0)   /* Used in density calcs    */
#define ACCRETE_J                       (1.46E-19)      /* Used in day-length calcs (cm2/sec2 g) */
#define ACCRETE_INCREDIBLY_LARGE_NUMBER (9.9999E37)

/*  Now for a few molecular weights (used for RMS velocity calcs):     */
/*  This table is from Dole's book "Habitable Planets for Man", p. 38  */

#define ACCRETE_ATOMIC_HYDROGEN         (1.0)   /* H   */
#define ACCRETE_MOL_HYDROGEN            (2.0)   /* H2  */
#define ACCRETE_HELIUM                  (4.0)   /* He  */
#define ACCRETE_ATOMIC_NITROGEN         (14.0)  /* N   */
#define ACCRETE_ATOMIC_OXYGEN           (16.0)  /* O   */
#define ACCRETE_METHANE                 (16.0)  /* CH4 */
#define ACCRETE_AMMONIA                 (17.0)  /* NH3 */
#define ACCRETE_WATER_VAPOR             (18.0)  /* H2O */
#define ACCRETE_NEON                    (20.2)  /* Ne  */
#define ACCRETE_MOL_NITROGEN            (28.0)  /* N2  */
#define ACCRETE_CARBON_MONOXIDE         (28.0)  /* CO  */
#define ACCRETE_NITRIC_OXIDE            (30.0)  /* NO  */
#define ACCRETE_MOL_OXYGEN              (32.0)  /* O2  */
#define ACCRETE_HYDROGEN_SULPHIDE       (34.1)  /* H2S */
#define ACCRETE_ARGON                   (39.9)  /* Ar  */
#define ACCRETE_CARBON_DIOXIDE          (44.0)  /* CO2 */
#define ACCRETE_NITROUS_OXIDE           (44.0)  /* N2O */
#define ACCRETE_NITROGEN_DIOXIDE        (46.0)  /* NO2 */
#define ACCRETE_OZONE                   (48.0)  /* O3  */
#define ACCRETE_SULPH_DIOXIDE           (64.1)  /* SO2 */
#define ACCRETE_SULPH_TRIOXIDE          (80.1)  /* SO3 */
#define ACCRETE_KRYPTON                 (83.8)  /* Kr  */
#define ACCRETE_XENON                   (131.3)         /* Xe  */

/*  The following defines are used in the kothari_radius function in    */
/*  file enviro.c.                                                      */
#define ACCRETE_A1_20                   (6.485E12)      /* All units are in cgs system.  */
#define ACCRETE_A2_20                   (4.0032E-8)     /*   ie: cm, g, dynes, etc.      */
#define ACCRETE_BETA_20                 (5.71E12)

/*   The following defines are used in determining the fraction of a planet  */
/*  covered with clouds in function cloud_fraction in file enviro.c.         */
#define ACCRETE_Q1_36                   (1.258E19)      /* grams    */
#define ACCRETE_Q2_36                   (0.0698)        /* 1/Kelvin */

/* macros: */
#define ACCRETE_pow2(a) ((a) * (a))
#define ACCRETE_pow3(a) ((a) * (a) * (a))
#define ACCRETE_pow1_4(a)       sqrt(sqrt(a))
