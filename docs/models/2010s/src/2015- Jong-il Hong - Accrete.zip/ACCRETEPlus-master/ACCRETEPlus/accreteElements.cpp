
#include <stdlib.h>
#include <string.h>

#include "accreteElements.h"
#include "accreteAccrete.h"

namespace accrete
{

	static int compare_by_weight(const void* ap, const void* bp)
	{
		const SElement* a = *(SElement**)ap;
		const SElement* b = *(SElement**)bp;

		if (a->weight > b->weight)
			return +1;

		return a->weight < b->weight ? -1 : 0;
	}

	static int compare_by_melting_point(const void* ap, const void* bp)
	{
		const SElement* a = *(SElement**)ap;
		const SElement* b = *(SElement**)bp;

		if (a->melt > b->melt)
			return +1;

		return a->melt < b->melt ? -1 : 0;
	}

	static int compare_by_boiling_point(const void* ap, const void* bp)
	{
		const SElement* a = *(SElement**)ap;
		const SElement* b = *(SElement**)bp;

		if (a->boil > b->boil)
			return +1;

		return a->boil < b->boil ? -1 : 0;
	}

	static int compare_by_abundance(const void* ap, const void* bp)
	{
		const SElement* a = *(SElement**)ap;
		const SElement* b = *(SElement**)bp;
		double aa = a->abunds * a->abunde;
		double bb = b->abunds * b->abunde;

		if (aa > bb)
			return +1;

		return aa < bb ? -1 : 0;
	}

	static SElement* find_symbol(const char* sym)
	{
		for (SElement* p = elements; p->num; p++)
			if (strcmp(sym, p->symbol) == 0)
				return p;

		return nullptr;
	}

	int make_element_vector(char *str, SElement** vec, int max)
	{
		char* list = (char*)GMallocPtr(strlen(str) + 1);
		int num = 0;

		if (!list)
			return -1;

		if (!vec)
			return 0;

		strcpy(list, str);

		for (char* p = strtok(list, " "); num < max && nullptr != p; p = strtok(nullptr, " "))
		{
			vec[num] = find_symbol(p);

			if (vec[num])
				num++;
		}

		GFreePtr(list);
		return num;
	}

	static char* sort_elements(char *list, int fn(const void* , const void* ))
	{
		SElement** vec = (SElement**)GMallocPtr(strlen(list) * sizeof(SElement* ));
		int num = make_element_vector(list, vec, (int)strlen(list));

		if (num)
		{
			strcpy(list, "");
			qsort(vec, num, sizeof(*vec), fn);

			for (int i = 0; i < num; i++)
			{
				if (i)
					strcat(list, " ");

				strcat(list, vec[i]->symbol);
			}
		}

		GFreePtr(vec);
		return list;
	}

	char* sort_elements_reverse(char *list)
	{
		SElement** vec = (SElement**)GMallocPtr(strlen(list) * sizeof(SElement* ));
		int num = make_element_vector(list, vec, (int)strlen(list));

		if (num)
		{
			strcpy(list, "");
			for (int i = num - 1; i >= 0; i--)
			{
				if (list[0])
					strcat(list, " ");
				strcat(list, vec[i]->symbol);
			}
		}
		GFreePtr(vec);
		return list;
	}

	char* sort_by_element_weight(char* list)
	{
		return sort_elements(list, compare_by_weight);
	}

	char* sort_elements_by_melting_point(char* list)
	{
		return sort_elements(list, compare_by_melting_point);
	}

	char* sort_elements_by_boiling_point(char* list)
	{
		return sort_elements(list, compare_by_boiling_point);
	}

	char* sort_elements_by_abundance(char* list)
	{
		return sort_elements(list, compare_by_abundance);
	}

	char* find_gas_elements_at_temp(char* out, double temperature)
	{
		strcpy(out, "");
		for (SElement* p = elements; p->num > 0; p++)
		{
			if (p->boil >= 0 && p->boil < temperature)
			{
				if (*out)
					strcat(out, " ");
				strcat(out, p->symbol);
			}
		}
		return out;
	}

	char* find_liquid_elements_at_temp(char* out, double temperature)
	{
		strcpy(out, "");
		for (SElement* p = elements; p->num > 0; p++)
		{
			if (p->melt >= 0 && p->melt < temperature)
			{
				if (p->boil >= 0 && p->boil > temperature)
				{
					if (*out)
						strcat(out, " ");
					strcat(out, p->symbol);
				}
			}
		}
		return out;
	}

	char* find_solid_elements_at_temp(char* out, double temperature)
	{
		strcpy(out, "");
		for (SElement* p = elements; p->num > 0; p++)
		{
			if (p->melt > 0 && p->melt > temperature)
			{
				if (*out)
					strcat(out, " ");
				strcat(out, p->symbol);
			}
		}
		return out;
	}

	SElement elements[] =
	{
		{ 1, "H", "Hydrogen", 1.0079, 14.06, 20.40, 8.99e-05, 0.00125893, 27925.4, 1 },
		{ 2, "He", "Helium", 4.0026, 3.46, 4.20, 0.0001787, 7.94328e-09, 2722.7, 0 },
		{ 3, "Li", "Lithium", 6.9400, 453.74, 1620.00, 0.53, 1.99526e-05, 5.71479e-05, 1 },
		{ 4, "Be", "Beryllium", 9.0122, 1551.20, 2773.00, 1.848, 2.51189e-06, 7.29458e-07, 0 },
		{ 5, "B", "Boron", 10.8100, 2352.20, 3923.20, 2.34, 1e-05, 2.11836e-05, 0 },
		{ 6, "C", "Carbon", 12.0110, 3823.20, 5103.00, 2.62, 0.000199526, 10.0925, 0 },
		{ 7, "N", "Nitrogen", 14.0067, 63.34, 77.40, 0.0012506, 1.99526e-05, 3.13329, 0 },
		{ 8, "O", "Oxygen", 15.9994, 54.80, 90.20, 0.001429, 0.501187, 23.8232, 10 },
		{ 9, "F", "Fluorine", 18.9984, 53.58, 85.10, 0.001696, 0.000630957, 0.000843335, 40 },
		{ 10, "Ne", "Neon", 20.1700, 24.53, 27.10, 0.0009, 5.01187e-09, 3.4435e-5, 0 },
		{ 11, "Na", "Sodium", 22.9898, 371.01, 1154.60, 0.971, 0.0251189, 0.0574116, 5 },
		{ 12, "Mg", "Magnesium", 24.3050, 922.00, 1378.00, 1.738, 0.0251189, 1.07399, 2 },
		{ 13, "Al", "Aluminum", 26.9815, 933.57, 2740.00, 2.702, 0.0794328, 0.084918, 0 },
		{ 14, "Si", "Silicon", 28.0855, 1683.20, 3553.00, 2.33, 0.316228, 1, 0 },
		{ 15, "P", "Phosphorus", 30.9738, 317.30, 553.70, 1.82, 0.001, 0.0103992, 0 },
		{ 16, "S", "Sulfur", 32.0600, 386.00, 717.90, 2.07, 0.000251189, 0.515229, 0 },
		{ 17, "Cl", "Chlorine", 35.4530, 172.22, 239.20, 0.003214, 0.000125893, 0.005236, 30 },
		{ 18, "Ar", "Argon", 39.9480, 84.00, 87.30, 0.0017824, 3.16228e-06, 0.100925, 0 },
		{ 19, "K", "Potassium", 39.0983, 336.50, 1038.70, 0.862, 0.0199526, 0.00376704, 0 },
		{ 20, "Ca", "Calcium", 40.0800, 1112.20, 1767.00, 1.55, 0.0446684, 0.0610942, 0 },
		{ 21, "Sc", "Scandium", 44.9559, 1812.20, 3021.00, 3, 1.99526e-05, 3.41979e-05, 0 },
		{ 22, "Ti", "Titanium", 47.9000, 1933.20, 3558.00, 4.5, 0.00630957, 0.00239883, 0 },
		{ 23, "V", "Vanadium", 50.9415, 2163.20, 3623.00, 5.8, 0.000125893, 0.000293089, 0 },
		{ 24, "Cr", "Chromium", 51.9960, 2130.20, 2963.00, 7.19, 0.0001, 0.0134896, 0 },
		{ 25, "Mn", "Manganese", 54.9380, 1517.20, 2333.00, 7.43, 0.001, 0.00954993, 0 },
		{ 26, "Fe", "Iron", 55.8470, 1808.20, 3023.00, 7.86, 0.0630957, 0.899498, 0 },
		{ 27, "Co", "Cobalt", 58.9332, 1768.20, 3373.00, 8.9, 2.51189e-05, 0.00224905, 0 },
		{ 28, "Ni", "Nickel", 58.7100, 1726.20, 3193.00, 8.9, 7.94328e-05, 0.0493174, 0 },
		{ 29, "Cu", "Copper", 63.5460, 1356.60, 2843.00, 8.96, 5.01187e-05, 0.000522396, 0 },
		{ 30, "Zn", "Zinc", 65.3800, 692.78, 1180.00, 7.14, 6.16595e-05, 0.00125893, 0 },
		{ 31, "Ga", "Gallium", 69.7230, 302.98, 2676.00, 5.907, 1.58489e-05, 3.77572e-05, 1 },
		{ 32, "Ge", "Germanium", 72.5900, 1210.60, 3123.00, 5.323, 5.01187e-06, 0.000119124, 0 },
		{ 33, "As", "Arsenic", 74.9216, 886.00, 886.16, 5.72, 1.99526e-06, 6.56145e-06, 0 },
		{ 34, "Se", "Selenium", 78.9600, 490.20, 958.00, 4.79, 5.01187e-08, 6.20869e-05, 0 },
		{ 35, "Br", "Bromine", 79.9040, 266.00, 332.70, 3.119, 2.51189e-06, 1.18032e-05, 2 },
		{ 36, "Kr", "Krypton", 83.8000, 116.60, 119.70, 0.003708, 1e-10, 4.4978e-05, 0 },
		{ 37, "Rb", "Rubidium", 85.4670, 312.09, 961.00, 1.53, 0.0001, 7.09578e-06, 1 },
		{ 38, "Sr", "Strontium", 87.6200, 1042.20, 1654.00, 2.6, 0.000398107, 2.34963e-05, 0 },
		{ 39, "Y", "Yttrium", 88.9059, 1796.20, 3537.00, 4.47, 3.23594e-05, 4.64515e-06, 0 },
		{ 40, "Zr", "Zirconium", 91.2200, 2125.20, 4473.00, 6.4, 0.00017378, 1.14025e-05, 0 },
		{ 41, "Nb", "Niobium", 92.9064, 2741.20, 5031.00, 8.57, 1.99526e-05, 6.98232e-07, 0 },
		{ 42, "Mo", "Molybdenum", 95.9400, 2890.20, 4923.00, 10.2, 1.58489e-06, 2.5527e-06, 0 },
		{ 43, "Tc", "Technetium", 98.9062, 2445.20, 4840.00, 11.5, 0, 0, 0 },
		{ 44, "Ru", "Ruthenium", 101.0700, 2583.20, 4323.00, 12.2, 1e-09, 1.86209e-06, 0 },
		{ 45, "Rh", "Rhodium", 102.9055, 2238.20, 4033.00, 12.4, 1e-09, 3.4435e-07, 0 },
		{ 46, "Pd", "Palladium", 106.4000, 1827.20, 3213.00, 12.02, 1e-08, 1.38995e-06, 0 },
		{ 47, "Ag", "Silver", 107.8680, 1235.10, 2428.00, 10.5, 6.30957e-08, 4.86407e-07, 0 },
		{ 48, "Cd", "Cadmium", 112.4100, 594.10, 1038.00, 8.65, 1.99526e-07, 1.61065e-06, 0 },
		{ 49, "In", "Indium", 114.8200, 429.81, 2353.00, 7.31, 1e-07, 1.84077e-07, 0 },
		{ 50, "Sn", "Tin", 118.6900, 505.17, 2896.00, 7.3, 1.99526e-06, 3.81944e-06, 0 },
		{ 51, "Sb", "Antimony", 121.7500, 903.94, 1860.00, 6.684, 1.99526e-07, 3.0903e-07, 0 },
		{ 52, "Te", "Tellurium", 127.6000, 722.70, 1263.00, 6.24, 1e-09, 4.80839e-06, 0 },
		{ 53, "I", "Iodine", 126.9045, 386.70, 458.40, 4.93, 5.01187e-07, 8.99498e-07, 0 },
		{ 54, "Xe", "Xenon", 131.3000, 161.30, 165.00, 0.00588, 3.16228e-11, 4.69894e-06, 0 },
		{ 55, "Cs", "Cesium", 132.9054, 301.60, 978.00, 1.873, 1e-06, 3.72392e-07, 1 },
		{ 56, "Ba", "Barium", 137.3300, 998.20, 2123.00, 3.51, 0.000398107, 4.48745e-06, 0 },
		{ 57, "La", "Lanthanum", 138.9055, 1193.20, 3693.00, 6.7, 3.16228e-05, 4.45656e-07, 0 },
		{ 58, "Ce", "Cerium", 140.1200, 1071.20, 3743.00, 6.78, 6.30957e-05, 1.13501e-06, 0 },
		{ 59, "Pr", "Praseodymium", 140.9077, 1204.20, 3293.00, 6.77, 7.94328e-06, 1.66725e-07, 0 },
		{ 60, "Nd", "Neodymium", 144.2400, 1283.20, 3300.00, 7, 2.51189e-05, 8.27942e-07, 0 },
		{ 61, "Pm", "Promethium", 145.0000, 1353.20, -1.00, 6.475, 5.01187e-26, 0, 0 },
		{ 62, "Sm", "Samarium", 150.4000, 1345.20, 2073.00, 7.54, 6.30957e-06, 2.58226e-07, 0 },
		{ 63, "Eu", "Europium", 151.9600, 1095.20, 1712.00, 5.259, 1.25893e-06, 9.72747e-08, 0 },
		{ 64, "Gd", "Gadolinium", 157.2500, 1584.20, 3273.00, 7.895, 5.01187e-06, 3.3037e-07, 0 },
		{ 65, "Tb", "Terbium", 158.9254, 1633.20, 3073.00, 8.27, 1e-06, 6.0256e-08, 0 },
		{ 66, "Dy", "Dysprosium", 162.5000, 1682.20, 2873.00, 8.536, 3.16228e-06, 3.94457e-07, 0 },
		{ 67, "Ho", "Holmium", 164.9304, 1743.20, 2873.00, 8.8, 1.25893e-06, 8.89201e-08, 0 },
		{ 68, "Er", "Erbium", 167.2600, 1795.20, 3173.00, 9.05, 2.51189e-06, 2.50611e-07, 0 },
		{ 69, "Tm", "Thulium", 168.9342, 1818.20, 2000.00, 9.33, 5.01187e-07, 3.77572e-08, 0 },
		{ 70, "Yb", "Ytterbium", 173.0400, 1097.20, 1700.00, 6.98, 3.16228e-06, 2.47742e-07, 0 },
		{ 71, "Lu", "Lutetium", 174.9600, 1929.20, 3600.00, 9.85, 5.01187e-07, 3.67282e-08, 0 },
		{ 72, "Hf", "Hafnium", 178.4900, 2495.20, 4723.00, 13.2, 2.51189e-06, 1.5417e-07, 0 },
		{ 73, "Ta", "Tantalum", 180.9470, 3269.20, 5807.00, 16.6, 1.99526e-06, 2.07014e-08, 0 },
		{ 74, "W", "Tungsten", 183.8500, 3683.20, 5773.00, 19.3, 1.58489e-06, 1.33045e-07, 0 },
		{ 75, "Re", "Rhenium", 186.2070, 3453.20, 5923.00, 21, 5.01187e-09, 5.16416e-08, 0 },
		{ 76, "Os", "Osmium", 190.2000, 3318.20, 5298.00, 22.4, 1.58489e-09, 6.74528e-07, 0 },
		{ 77, "Ir", "Iridium", 192.2200, 2683.20, 4823.00, 22.42, 1e-09, 6.60693e-07, 0 },
		{ 78, "Pt", "Platinum", 195.0900, 2045.20, 4443.00, 21.45, 5.01187e-09, 1.33968e-06, 0 },
		{ 79, "Au", "Gold", 196.9665, 1337.63, 3081.00, 19.32, 3.98107e-09, 1.87068e-07, 0 },
		{ 80, "Hg", "Mercury", 200.5900, 234.33, 630.00, 13.546, 7.94328e-08, 3.39625e-07, 0 },
		{ 81, "Tl", "Thallium", 204.3700, 576.70, 1730.00, 11.85, 5.01187e-07, 1.84077e-07, 0 },
		{ 82, "Pb", "Lead", 207.2000, 600.70, 2024.00, 11.34, 1.25893e-05, 3.14775e-06, 0 },
		{ 83, "Bi", "Bismuth", 208.9804, 544.50, 1837.00, 9.8, 1.58489e-07, 1.4388e-07, 0 },
		{ 84, "Po", "Polonium", 209.0000, 527.20, 1235.00, 9.4, 1.99526e-16, 0, 0 },
		{ 85, "At", "Astatine", 210.0000, 575.20, 610.16, 0, 0, 0, 0 },
		{ 86, "Rn", "Radon", 222.0000, 202.20, 211.00, 0.00973, 3.98107e-19, 0, 0 },
		{ 87, "Fr", "Francium", 223.0000, 300.20, 950.00, 0, 0, 0, 0 },
		{ 88, "Ra", "Radium", 226.0254, 973.20, 1973.00, 5, 1e-12, 0, 0 },
		{ 89, "Ac", "Actinium", 227.0000, 1323.20, 2743.00, 10.07, 5.01187e-16, 0, 0 },
		{ 90, "Th", "Thorium", 232.0381, 2023.20, 5123.00, 11.7, 1e-05, 3.34965e-08, 0 },
		{ 91, "Pa", "Protactinium", 231.0359, 1873.20, 4500.00, 15.4, 1.25893e-12, 0, 0 },
		{ 92, "U", "Uranium", 238.0290, 1405.20, 4203.00, 18.9, 2.51189e-06, 8.99498e-09, 0 },
		{ 93, "Np", "Neptunium", 237.0482, 913.20, 4175.00, 20.45, 0, 0, 0 },
		{ 94, "Pu", "Plutonium", 244.0000, 914.20, 3503.00, 19.8, 0, 0, 0 },
		{ 95, "Am", "Americium", 243.0000, 1267.20, 2873.00, 13.6, 0, 0, 0 },
		{ 96, "Cm", "Curium", 247.0000, 1613.20, -1.00, 13.5, 0, 0, 0 },
		{ 97, "Bk", "Berkelium", 247.0000, 1259.20, -1.00, 0, 0, 0, 0 },
		{ 98, "Cf", "Californium", 251.0000, 1173.20, -1.00, 0, 0, 0, 0 },
		{ 99, "Es", "Einsteinium", 254.0000, 1133.20, -1.00, 0, 0, 0, 0 },
		{ 100, "Fm", "Fermium", 257.0000, -1.00, -1.00, 0, 0, 0, 0 },
		{ 101, "Md", "Mendelevium", 258.0000, -1.00, -1.00, 0, 0, 0, 0 },
		{ 102, "No", "Nobelium", 259.0000, -1.00, -1.00, 0, 0, 0, 0 },
		{ 103, "Lr", "Lawrencium", 260.0000, -1.00, -1.00, 0, 0, 0, 0 },
		{ 104, "Rf", "Rutherfordium", 261.0000, -1.00, -1.00, 0, 1e-06, 1e-06, 0 },
		{ 105, "Db", "Dubnium", 262.0000, -1.00, -1.00, 0, 1e-06, 1e-06, 0 },
		{ 106, "Sg", "Seaborgium", 263.0000, -1.00, -1.00, 0, 1e-06, 1e-06, 0 },
		{ 107, "Bh", "Bohrium", 262.0000, -1.00, -1.00, 0, 1e-06, 1e-06, 0 },
		{ 108, "Hs", "Hassium", 265.0000, -1.00, -1.00, 0, 1e-06, 1e-06, 0 },
		{ 109, "Mt", "Meitnerium", 266.0000, -1.00, -1.00, 0, 1e-06, 1e-06, 0 },
		{ 110, "Uun", "Ununnilium", 272.0000, -1.00, -1.00, 0, 1e-06, 1e-06, 0 },

		/* An   sym    name             Aw  melt    boil    dens   ABUNDe ABUNDs Rea */
		{ 900, "NH3", "Ammonia", 17, 195.46, 239.66, 0.001, 0.002, 0.001, 0.001 },
		{ 901, "H2O", "Water", 18, 273.16, 373.16, 1.000, 0.03, 0.001, 0 },
		{ 902, "CO2", "CarbonDioxide", 44, 194.66, 194.66, 0.001, 0.01, 0.001, 0 },
		{ 903, "O3", "Ozone", 48, 80.16, 161.16, 0.001, 0.001, 0.001, 0.001 },
		{ 904, "CH4", "Methane", 16, 90.16, 109.16, 0.010, 0.005, 0.001, 0 },
		{ 905, "CH3CH2OH", "Ethanol", 46, 159.06, 351.66, 0.895, 0.001, 0.001, 0 },
		{ 999, "", "", 0, -1, -1, 0, 0, 0, 0 },
		{ 0, "", "", 0, 0, 0, 0, 0, 0, 0 }
	};

}