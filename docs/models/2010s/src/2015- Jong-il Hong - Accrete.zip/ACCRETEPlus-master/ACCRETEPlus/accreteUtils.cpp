
#include <stdlib.h>
#include <math.h>

#include "accreteUtils.h"
#include "accreteConst.h"

namespace accrete
{

#ifndef RAND_MAX
	#define RAND_MAX        (32767.0)
#endif

	double DefaultRandom(double Min, double Max)
	{
		unsigned long r = ::rand();
		double rr = (double)r / ((double)RAND_MAX);
		double range = Max - Min;
		return rr * range + Min;
	}
	RandomFunc GRandomPtr(DefaultRandom);


	/*----------------------------------------------------------------------*/
	/*  This function returns a random real number between the specified    */
	/* inner and outer bounds.                                              */
	/*----------------------------------------------------------------------*/

	double random_number(double inner, double outer)
	{
		return GRandomPtr(inner, outer);
	}

	/*----------------------------------------------------------------------*/
	/*   This function returns a value within a certain variation of the    */
	/*   exact value given it in 'value'.                                   */
	/*----------------------------------------------------------------------*/

	double about(double value, double variation)
	{
		return value + (value * random_number(-variation, variation));
	}

	double random_eccentricity(void)
	{
		return 1.0 - pow(random_number(0.000001, 1.0), ACCRETE_ECCENTRICITY_COEFF);
	}

}