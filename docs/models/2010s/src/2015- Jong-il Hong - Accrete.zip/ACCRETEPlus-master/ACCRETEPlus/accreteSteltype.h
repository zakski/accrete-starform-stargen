#pragma once

namespace accrete
{

	struct SStellarType
	{
		const char *star_class;
		double      temp;
		const char *balmer;
		const char *lines;
		double      mass;
		double      size;
		double      density;
		double      lum;
		double      star_age;
	};

	extern SStellarType STAR_TYPES[];

	const char* find_star_class(double temperature);

}
