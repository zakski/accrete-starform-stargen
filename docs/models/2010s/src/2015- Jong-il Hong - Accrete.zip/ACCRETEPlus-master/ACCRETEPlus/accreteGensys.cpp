
#include <stdio.h>
//#include <sys/time.h>
#include <math.h>
#include <stdlib.h>

#include "accreteGensys.h"
#include "accreteStructs.h"
#include "accreteAccrete.h"
#include "accreteEnviro.h"
#include "accreteSteltype.h"
#include "accreteDisplay.h"

namespace accrete
{

	SStellarSystem* generate_stellar_system(double star_mass)
	{
		SPlanet* cur_planet;
		double      outer_dust_limit;

		SStellarSystem *system = (SStellarSystem*)GMallocPtr(sizeof(SStellarSystem));
		memset(system, 0, sizeof(SStellarSystem));

		system->star_mass_r = star_mass;// random_number(0.6, 1.3);  /* was 0.6, 1.3 */
		system->star_radius_r = about(pow(system->star_mass_r, 1.0 / 3.0), 0.05);
		/* for some unknown reason, only 3 digits wanted... */
		system->star_radius_r = floor(system->star_radius_r * 1000.0) / 1000.0;
		system->star_lum_r = luminosity(system->star_mass_r);
		/* luminosity is proportional to T^4 and to area of star */
		/* so temp is Tsol * 4th-root ( Lum / r^2 )              */
		system->star_temp = 5650 * sqrt(sqrt(system->star_lum_r) / system->star_radius_r);
		/* ignore fractional degrees */
		system->star_temp = floor(system->star_temp);
		sprintf(system->star_class, "%.16s", find_star_class(system->star_temp));
		outer_dust_limit = stellar_dust_limit(system->star_mass_r);
		system->first_planet = distribute_planetary_masses(system, 0.0, outer_dust_limit);
		system->main_seq_life = 1.0E10 * (system->star_mass_r / system->star_lum_r);
		if (system->main_seq_life > 6.0E9)
			system->star_age = random_number(1.0E9, 6.0E9);
		else if (system->main_seq_life > 1.0E9)
			system->star_age = random_number(1.0E9, system->main_seq_life);
		else
			system->star_age = random_number(system->main_seq_life / 10, system->main_seq_life);
		system->r_ecosphere = sqrt(system->star_lum_r);
		system->r_greenhouse = system->r_ecosphere * ACCRETE_GREENHOUSE_EFFECT_CONST;
		for (cur_planet = system->first_planet; cur_planet != nullptr; cur_planet = cur_planet->next_planet)
		{
			cur_planet->orbit_zone = orbital_zone(system, cur_planet->a);
			if (cur_planet->gas_giant)
			{
				cur_planet->density = empirical_density(system, cur_planet->mass, cur_planet->a,
					cur_planet->gas_giant);
				cur_planet->radius = volume_radius(cur_planet->mass, cur_planet->density);
			}
			else
			{
				cur_planet->radius = kothari_radius(cur_planet->mass, cur_planet->gas_giant,
					cur_planet->orbit_zone);
				cur_planet->density = volume_density(cur_planet->mass, cur_planet->radius);
			}
			cur_planet->orb_period = period(cur_planet->a, cur_planet->mass, system->star_mass_r);
			cur_planet->day = day_length(system, cur_planet->mass, cur_planet->radius, cur_planet->e,
				cur_planet->density, cur_planet->a,
				cur_planet->orb_period, cur_planet->gas_giant,
				system->star_mass_r);
			cur_planet->resonant_period = system->resonance;
			cur_planet->axial_tilt = inclination(cur_planet->a);
			cur_planet->esc_velocity = escape_velocity(cur_planet->mass, cur_planet->radius);
			cur_planet->surf_accel = acceleration(cur_planet->mass, cur_planet->radius);
			cur_planet->rms_velocity = rms_velocity(system, ACCRETE_MOL_NITROGEN, cur_planet->a);
			cur_planet->molec_weight = molecule_limit(cur_planet->mass, cur_planet->radius);
			if ((cur_planet->gas_giant))
			{
				cur_planet->surf_grav = ACCRETE_INCREDIBLY_LARGE_NUMBER;
				cur_planet->greenhouse_effect = false;
				cur_planet->volatile_gas_inventory = ACCRETE_INCREDIBLY_LARGE_NUMBER;
				cur_planet->surf_pressure = ACCRETE_INCREDIBLY_LARGE_NUMBER;
				cur_planet->boil_point = ACCRETE_INCREDIBLY_LARGE_NUMBER;
				cur_planet->hydrosphere = ACCRETE_INCREDIBLY_LARGE_NUMBER;
				cur_planet->albedo = about(ACCRETE_GAS_GIANT_ALBEDO, 0.1);
				cur_planet->surf_temp = ACCRETE_INCREDIBLY_LARGE_NUMBER;
			}
			else
			{
				cur_planet->surf_grav = gravity(cur_planet->surf_accel);
				cur_planet->greenhouse_effect = greenhouse(cur_planet->orbit_zone, cur_planet->a,
					system->r_greenhouse);
				cur_planet->volatile_gas_inventory = vol_inventory(cur_planet->mass,
					cur_planet->esc_velocity,
					cur_planet->rms_velocity,
					system->star_mass_r,
					cur_planet->orbit_zone,
					cur_planet->greenhouse_effect);
				cur_planet->surf_pressure = pressure(cur_planet->volatile_gas_inventory,
					cur_planet->radius, cur_planet->surf_grav);
				if (cur_planet->surf_pressure == 0.0)
					cur_planet->boil_point = 0.0;
				else
					cur_planet->boil_point = boiling_point(cur_planet->surf_pressure);
				iterate_surface_temp(system, &(cur_planet));
			}
#ifdef  ACCRETE_MOON
			if (args.make_moon)
			{
#if  0
				cur_planet->first_moon = dist_moon_masses(cur_planet->mass,
					system->star_lum_r, cur_planet->e,
					0.0, planet_dust_limit(cur_planet->mass));
#else
				cur_planet->first_moon = do_dist_moon_masses(cur_planet->mass, cur_planet->radius);
				{
					SPlanet* moon = cur_planet->first_moon;

					while (moon)
					{
						moon->radius = kothari_radius(moon->mass, 0, cur_planet->orbit_zone);
						moon->density = volume_density(moon->mass, moon->radius);
						moon->density = random_number(1.5, moon->density * 1.1);
						if (moon->density < 1.5)
							moon->density = 1.5;
						moon->radius = volume_radius(moon->mass, moon->density);
						moon->orb_period = period(moon->a, moon->mass, cur_planet->mass);
						moon->day = day_length(system, moon->mass, moon->radius, moon->e,
							moon->density, moon->a,
							moon->orb_period, moon->gas_giant,
							cur_planet->mass);
						moon->resonant_period = system->resonance;
						moon->axial_tilt = inclination(moon->a);
						moon->esc_velocity = escape_velocity(moon->mass, moon->radius);
						moon->surf_accel = acceleration(moon->mass, moon->radius);
						moon->rms_velocity = rms_velocity(system, ACCRETE_MOL_NITROGEN, cur_planet->a);
						moon->molec_weight = molecule_limit(moon->mass, moon->radius);
						moon->surf_grav = gravity(moon->surf_accel);
						moon->greenhouse_effect = greenhouse(cur_planet->orbit_zone,
							cur_planet->a,
							system->r_greenhouse);
						moon->volatile_gas_inventory = vol_inventory(moon->mass,
							moon->esc_velocity,
							moon->rms_velocity,
							system->star_mass_r,
							cur_planet->orbit_zone,
							moon->greenhouse_effect);
						moon->surf_pressure = pressure(moon->volatile_gas_inventory,
							moon->radius, moon->surf_grav);
						if ((moon->surf_pressure == 0.0))
							moon->boil_point = 0.0;
						else
							moon->boil_point = boiling_point(moon->surf_pressure);
						iterate_surface_temp_moon(system, &cur_planet, &moon);
						moon = moon->next_planet;
					}
				}
#endif        /* CC_MOON */
			}
#endif        /* ACCRETE_MOON */
		}
		return system;
	}

	void free_stellar_system(SStellarSystem* system)
	{
		// first, free all the planets
		SPlanet *p, *q = nullptr;
		for (p = system->first_planet;
			p != nullptr;
			p = q)
		{
			q = p->next_planet;

			// free moons
			SPlanet* m = p->first_moon;
			while (nullptr != m)
			{
				SPlanet* cm = m;
				m = cm->next_planet;
				GFreePtr(cm);
			}
			GFreePtr(p);
		}

		// now, free the system
		GFreePtr(system);
	}

}