//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by WinStarGen.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_WinStarGenTYPE              129
#define IDS_CATALOG_DLG_TITLE           129
#define IDD_RANDOM_VALUES_DIALOG        130
#define IDD_STELLAR_MASS_DIALOG         131
#define IDD_CATALOG_DIALOG              132
#define IDC_COUNT_EDIT                  1000
#define IDC_NAME_EDIT                   1001
#define IDC_RANDOM_RADIO                1002
#define IDC_SPECIFY_SEED_RADIO          1003
#define IDC_SEED_EDIT                   1004
#define IDC_SEED_STATIC                 1005
#define IDC_INCREMENT_EDIT              1006
#define IDC_EDIT1                       1009
#define IDC_MASS_EDIT                   1009
#define IDC_SINGLE_SYSTEM_RADIO         1010
#define IDC_BASED_ON_COMBO              1011
#define IDC_ENTIRE_CATALOG_RADIO        1012
#define IDC_EDIT2                       1013
#define IDC_REPEAT_EDIT                 1013
#define IDC_BASED_ON_STATIC             1014
#define IDC_COUNT_STATIC                1015
#define IDC_REPEAT_STATIC               1016
#define ID_FILE_REDO                    32771
#define ID_GENERATEBASEDON_STELLARMASS  32774
#define ID_FILE_RELOADPAGE              32775
#define ID_GENERATEBASEDON_RANDOMVALUES 32777
#define ID_BUTTON32778                  32778
#define ID_BUTTON32779                  32779
#define ID_GENERATEBASEDON_SOLSTATIONCATALOGSYSTEM 32781
#define ID_GENERATEBASEDON_DOLECATALOGSYSTEM 32782
#define ID_GENERATEBASEDON_SHOWATMOSPHERICGASES 32783
#define ID_MIN2HABITABLEPLANETS         32787
#define ID_MIN1HABITABLEPLANET          32788
#define ID_NOHABITABLEPLANETSREQUIRED   32789
#define ID_HELP_USINGWINSTARGEN         32790
#define ID_FILE_EXPORT_FOR_WEB          32791
#define ID_BUTTON32792                  32792
#define ID_BUTTON32793                  32793
#define ID_BUTTON32794                  32794
#define ID_BUTTON32795                  32795

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
