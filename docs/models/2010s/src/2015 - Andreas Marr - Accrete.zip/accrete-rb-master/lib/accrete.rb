# -*- encoding: utf-8 -*-

module Accrete
  require 'accrete/version'

  require 'accrete/star'
end
