# -*- encoding: utf-8 -*-

module Accrete
  VERSION = '0.0.1'
  def self.version
    VERSION
  end
end
