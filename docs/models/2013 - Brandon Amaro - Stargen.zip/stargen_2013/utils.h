long double random_number(long double, long double);
long double about(long double, long double);
long double random_eccentricity(long double);
long double gaussian(long double);
long double Exponential(long double);
long Poisson (long double);
long double quad_trend(long double, long double, long double, long double);
long double ln_trend(long double, long double, long double);
long double gen_radii(long double, long double, long double, long double, long double, long double, long double, long double);