
extern catalog ring_universe;
