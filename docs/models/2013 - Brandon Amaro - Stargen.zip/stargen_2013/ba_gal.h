
extern catalog ba_gal;