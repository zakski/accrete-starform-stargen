extern catalog omega_galaxy;
