Program File_Generator;

typedef struct
        {
	    st_type : char[2];
	    mass : float;
	    radius : float;
	    luminosity : float;
         }  Star_Record;
    Star_Record Star_Data[33];

var
  Star_File : File of Star_Data[33];
  infile : text;
  i : integer;
  
begin
page(output);
  reset(infile,'#5:stardata.text');
  rewrite(Star_File,'#5:Star_Data');
  fillchar(Star_File^,sizeof(Star_Data),0);
  for i:= 1 to 33 do
    with star_File^[i] do
    begin
      readln(infile,st_type);
      readln(infile,mass,radius,luminosity);
      writeln(st_type:10,mass:6:3,radius:6:2,luminosity:8:4);
    end;
  seek(star_file,0);
  put(star_File);
  close(infile,lock);
  close(star_file,lock);
end.
