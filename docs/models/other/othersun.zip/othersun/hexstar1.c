/*****************************************/
/* Program:      Star_Generator          */
/* Version:      1.0                     */
/* Filename:     HEXSTAR1.TEXT           */
/* Author:       Sean R. Malloy          */
/* Created:      19-Oct-83               */
/* Last Update:  13-Jun-84               */
/*****************************************/
/* This program generates star positions */
/* in a 120 light year hex, suitable for */
/* mapping purposes for Other Suns.      */
/* The companion programs are HEXSTAR2   */
/* and HEXSTAR3, which set up and output */
/* the information created by this file. */
/*****************************************/

/*------------------------------------------------------------------------
The changes necessary to make this program generate star positions within
a volume other than a 'hex' 120 light years across are trivial, and are
accomplished simply by setting different constraints on the generation
of the x, y, and z coordinates of the star.
------------------------------------------------------------------------*/


#include <stdio.h>
#include <math.h>

#define TRUE 1
#define FALSE 0

typedef int boolean;

typedef struct 			/* record type for data on a star type */
        {						/* examples for Sol: */
            char s_type[2];		/* "G2" */
            float mass;			/* 1.00 */
            float radius;		/* 1.00 */
            float luminosity;	/* 1.00 */
        } star_rec;
    
typedef struct 			/* record type for generic system info */
        {
            int x_pos, y_pos, z_pos;	/* coords of primary */
            int star_quant;				/* number of stars in system */
            int stars[4];				/* indices into array of star_rec */
            boolean companion;			/* primary has dark companion */
            boolean planets;			/* primary has planets */
        } starsys_rec;

char *clearfunc = "/bin/clear";

int roll;
char ch;
starsys_rec starsys_data;
  
main()
{
    system(clearfunc);
    printf(stderr,"Other Suns Star System Generator, Program 1 of 3\n");
    printf(stderr,"Working...\n");
    srand(time() % 32768);
    mainloop();
    printf(stderr,"Done...\n");
}

int random(lo,hi)		/* return a random number x such that lo <= x <= hi */
int lo,hi;
{
    return(lo + ((hi-lo)*(((double) rand())/32768.0)));
}

int dice(num,size)		/* roll <num> <size>-sided dice */
int num,size;
{
    int i,sum;

    sum= 0;
    for (i == 0; i< num;i++)
        sum= sum + random(1,size);
    return(sum);
} 

boolean subrange(val,lo,hi)	/* returns TRUE if  lo <= val <= hi */
int val,lo,hi;
{
    if ((val>=lo)&&(val<=hi)) return(TRUE);
    return(FALSE);
}


int f_type()
{
    int rollf;

    rollf= random(1,100);
    if (subrange(rollf,1,17)) return(1);	/* star is type F5 */
    if (subrange(rollf,18,36)) return(2);	/* star is type F6 */
    if (subrange(rollf,37,57)) return(3);	/* star is type F7 */
    if (subrange(rollf,58,78)) return(4);	/* star is type F8 */
    if (subrange(rollf,79,100)) return(5);	/* star is type F9 */
}

int g_type()
{
    int rollg;

    rollg= random(1,100);
    if (subrange(rollg,1,8)) return(6);		/* star is type G0 */
    if (subrange(rollg,9,16)) return(7);	/* star is type G1 */
    if (subrange(rollg,17,24)) return(8);	/* star is type G2 */
    if (subrange(rollg,25,33)) return(9);	/* star is type G3 */
    if (subrange(rollg,34,42)) return(10);	/* star is type G4 */
    if (subrange(rollg,43,51)) return(11);	/* star is type G5 */
    if (subrange(rollg,52,61)) return(12);	/* star is type G6 */
    if (subrange(rollg,62,73)) return(13);	/* star is type G7 */
    if (subrange(rollg,74,86)) return(14);	/* star is type G8 */
    if (subrange(rollg,87,100)) return(15);	/* star is type G9 */
}

int k_type()
{
    int rollk;

    rollk= random(1,100);
    if (subrange(rollk,1,8)) return(16);	/* star is type K0 */
    if (subrange(rollk,9,16)) return(17);	/* star is type K1 */
    if (subrange(rollk,17,24)) return(18);	/* star is type K2 */
    if (subrange(rollk,25,33)) return(19);	/* star is type K3 */
    if (subrange(rollk,34,42)) return(20);	/* star is type K4 */
    if (subrange(rollk,43,52)) return(21);	/* star is type K5 */
    if (subrange(rollk,53,62)) return(22);	/* star is type K6 */
    if (subrange(rollk,63,74)) return(23);	/* star is type K7 */
    if (subrange(rollk,75,86)) return(24);	/* star is type K8 */
    if (subrange(rollk,87,100)) return(25);	/* star is type K9 */
}

int m_type()
{
    int rollm;

    rollm= random(1,100);
    if (subrange(rollm,1,4)) return(26);	/* star is type M0 */
    if (subrange(rollm,5,9)) return(27);	/* star is type M1 */
    if (subrange(rollm,10,15)) return(28);	/* star is type M2 */
    if (subrange(rollm,16,22)) return(29);	/* star is type M3 */
    if (subrange(rollm,23,32)) return(30);	/* star is type M4 */
    if (subrange(rollm,33,47)) return(31);	/* star is type M5 */
    if (subrange(rollm,48,70)) return(32);	/* star is type M6 */
    if (subrange(rollm,71,100)) return(33);	/* star is type M7 */
}

/*-------------------------------------------------------------
note - The Other Suns star system generation rules only deal with 
main sequence stars between types F5 and M7.
-------------------------------------------------------------*/

int get_star()	
{
    roll= random(1,100);
    if (subrange(roll,1,3)) return(f_type());		/* 3% type F */
    if (subrange(roll,4,12)) return(g_type());		/* 9% type G */
    if (subrange(roll,13,29)) return(k_type());		/* 17% type K */
    if (subrange(roll,30,100)) return(m_type());	/* 71% type M */
}

void coordinates(x_pos, y_pos, z_pos)
int *x_pos,*y_pos,*z_pos;
{
    do								/* generate x-y pairs */
    {								/* until x-y position is within */
        *x_pos= random(-60,60);		/* the boundaries of the hex */
        *y_pos= random(-60,60);
    }
    while (abs(*x_pos) >= (120 - 2*abs(*y_pos)));	
    *z_pos= random(-60,60);			/* then generate the z coord */
}
    
void mainloop()
{
    int i,j;
    extern starsys_rec starsys_data;

    for (i= 0; i<1000; i++)		/* make 1000 stars in hex */
    {		/* volume is ~1.12E6 cu. ly; 1 star per 1122 cu. ly */
       coordinates(&starsys_data.x_pos,&starsys_data.y_pos,&starsys_data.z_pos);
        starsys_data.companion= FALSE;
        starsys_data.planets= FALSE;
        roll= dice(1,100);
			/* 1% chance for quaternary star system */
        if (roll == 1) starsys_data.star_quant= 4;
			/* 7% chance for trinary star system */
        if (subrange(roll,2,8)) starsys_data.star_quant= 3;
			/* 45% chance for binary star system */
        if (subrange(roll,9,54)) starsys_data.star_quant= 2;
			/* 46% chance for single primary star system */
        if (subrange(roll,55,100)) starsys_data.star_quant= 1;
        if (subrange(roll,55,67)) starsys_data.companion= TRUE;
        if (subrange(roll,90,100)) starsys_data.planets= TRUE;
        for (j= 0;j<starsys_data.star_quant;j++)
            starsys_data.stars[j]= get_star();
	/*****/
	/* output star system info to stdout. Really primitive output setup, */
	/* but I wasn't trying for sophistication with this version */
	/*****/
printf("%5d %5d %5d ",starsys_data.x_pos,starsys_data.y_pos,starsys_data.z_pos);
    printf("%5d ",starsys_data.star_quant);
for (j=0;j<starsys_data.star_quant;j++)
    printf("%5d ",starsys_data.stars[j]);
printf("%5d %5d\n",starsys_data.companion,starsys_data.planets);
        printf(stderr,".");
        if (i % 50) printf(stderr,"\n");
    }
}

