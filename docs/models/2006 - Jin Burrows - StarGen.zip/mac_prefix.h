#include <ansi_prefix.mac.h>
#define MEMORY_CHECK 1
