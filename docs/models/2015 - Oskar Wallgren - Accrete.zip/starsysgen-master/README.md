# Starsysgen
Things to generate starsystems like accrete and standalone apps lifted from vegastrike.
NB. 'Starsystem' in this case meaning a descriptive list of star type and planets. Nothing fancy graphical!

# Packages
- Starsystemgen from Vegastrike. ( defunct and deprecated )
- Accrete
