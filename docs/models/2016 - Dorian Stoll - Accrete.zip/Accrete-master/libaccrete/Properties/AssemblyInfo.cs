﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("libaccrete")]
[assembly: AssemblyDescription("A physical simulation of solar system planet formation.")]
[assembly: AssemblyProduct("libaccrete")]
[assembly: AssemblyCopyright("Copyright © Joe Nowakowski, Chuck Swiger, Dorian Stoll 2016")]
[assembly: ComVisible(false)]
[assembly: Guid("261efccc-4878-4a36-8537-3587e9d0ea66")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
