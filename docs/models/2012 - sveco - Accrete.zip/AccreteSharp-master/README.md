AccreteSharp
============

Long ago I found a program written in C by Matt Burdick, based on paper by  Stephen H. Dole "Habitable Planets for Man" (and it can still be found somewhere on net).
I decided to port this code to c#, and this repository is my last attempt to optimize code and update it with latest discoveries. I left original comments and old obsolete commented code for reference.

