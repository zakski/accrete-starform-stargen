#include "structs.h"
#include "gensys.h"

// there's an implicit dependency between these and the arguments
// struct. -DKL

void verbose_print(const char* message);
void display_system(stellar_system* system);
