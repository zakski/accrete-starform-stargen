#ifndef _UTILS_H
#define _UTILS_H

double random_number(double inner, double outer);
double about(double value, double variation);
double random_eccentricity(void);

#endif
