#ifndef STAR_TREK_H
#define STAR_TREK_H
#include "structs.h"

using namespace std;

extern catalog star_trek;

void initStarTrek();
#endif
