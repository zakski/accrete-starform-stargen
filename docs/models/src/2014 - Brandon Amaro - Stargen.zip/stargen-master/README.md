stargen

Stargen is a program that generates random solar systems
