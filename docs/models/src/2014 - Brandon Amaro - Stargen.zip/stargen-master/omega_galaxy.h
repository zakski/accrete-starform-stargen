#ifndef OMEGA_GALAXY_H
#define OMEGA_GALAXY_H
#include "structs.h"

using namespace std;

extern catalog omega_galaxy;

void initOmegaGalaxy();

#endif