#ifndef ANDROMEDA_H
#define ANDROMEDA_H
#include "structs.h"

using namespace std;

extern catalog andromeda;

void initAndromeda();

#endif