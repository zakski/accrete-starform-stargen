#ifndef RING_UNIVERSE_H
#define RING_UNIVERSE_H
#include "structs.h"

using namespace std;

extern catalog ring_universe;

void initRingUniverse();

#endif