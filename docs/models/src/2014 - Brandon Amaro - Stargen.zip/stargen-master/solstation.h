#ifndef SOLSTATION_H
#define SOLSTATION_H
#include "structs.h"

using namespace std;

extern catalog solstation;

void initSolStation();
#endif
