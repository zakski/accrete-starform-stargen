#ifndef JIMB_H
#define JIMB_H
#include "structs.h"

using namespace std;

extern catalog jimb;

void initJimb();
#endif
