#ifndef ANDROMEDA2_H
#define ANDROMEDA2_H

#include "c_structs.h"

extern old_star andromeda_stars[];
extern int total_andromeda_stars;

#endif