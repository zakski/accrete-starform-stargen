#ifndef PLANETARY_HABILITY_LABORATORY_H
#define PLANETARY_HABILITY_LABORATORY_H
#include "structs.h"

extern catalog phl;

void initPlanetaryHabitabilityLaboratory();

#endif
