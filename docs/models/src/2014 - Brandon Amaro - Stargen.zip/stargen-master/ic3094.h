#ifndef IC3094_H
#define IC3094_H
#include "structs.h"

using namespace std;

extern catalog ic3094;

void initIC3094();

#endif