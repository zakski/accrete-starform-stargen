#ifndef IC3094_2_H
#define IC3094_2_H

#include "c_structs.h"

extern old_star ic3094_stars[];
extern int total_ic3094_stars;

#endif