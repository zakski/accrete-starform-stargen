#ifndef OMEGA_GALAXY2_H
#define OMEGA_GALAXY2_H

#include "c_structs.h"

extern old_star ring_universe_stars[];
extern int total_ring_universe_stars;

#endif