#ifndef ELEMENTS_H
#define ELEMENTS_H
#include "structs.h"

extern ChemTable gases;

void initGases();

#endif
