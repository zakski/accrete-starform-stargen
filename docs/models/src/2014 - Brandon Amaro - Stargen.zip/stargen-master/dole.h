#ifndef DOLE_H
#define DOLE_H
#include "structs.h"

using namespace std;

extern catalog dole;

void initDole();
#endif
