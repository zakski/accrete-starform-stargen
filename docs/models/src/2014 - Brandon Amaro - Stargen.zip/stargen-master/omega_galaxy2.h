#ifndef OMEGA_GALAXY2_H
#define OMEGA_GALAXY2_H

#include "c_structs.h"

extern old_star omega_stars[];
extern int total_omega_stars;

#endif