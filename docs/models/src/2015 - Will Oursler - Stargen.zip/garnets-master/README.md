# Garnets

Port of the StarGen Stellar System Generator from C to Python. Focus on enhancing (even further!) readability and extensibility. The name is a Anagram.

# Inclusion of StarGen Code:
Some StarGen code is included as a reference while porting. Since StarGen is MIT Licensed, this in on the up and up. :)
