# Accrete

Nim reimplementation of Carl Sagan's planetar system generator. It may deviate from the original.

# Compilation

`nim compile --opt:size -d:release --deadCodeElim:on accrete.nim`
