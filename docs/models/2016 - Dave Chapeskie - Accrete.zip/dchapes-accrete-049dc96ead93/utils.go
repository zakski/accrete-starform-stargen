package accrete

import (
	crand "crypto/rand"
	"math"
	"math/rand"
	"time"
)

func seedRNG(seed int64) int64 {
	if seed != 0 {
		rand.Seed(seed)
	} else {
		seed = randomSeed()
	}
	return seed
}

func random(inner, outer float64) float64 {
	return rand.Float64()*(outer-inner) + inner
}

func about(v, variation float64) float64 {
	return v + v*random(-variation, variation)
}

func randomEccentricity() float64 {
	return 1 - math.Pow(rand.Float64(), eccentricityCoeff)
}

func exp(x float64) float64    { return math.Exp(x) }
func abs(x float64) float64    { return math.Abs(x) }
func log10(x float64) float64  { return math.Log10(x) }
func sqrt(x float64) float64   { return math.Sqrt(x) }
func pow(x, y float64) float64 { return math.Pow(x, y) }
func pow2(x float64) float64   { return x * x }
func pow3(x float64) float64   { return x * x * x }
func pow1_4(x float64) float64 { return math.Sqrt(math.Sqrt(x)) }

// Adapted from unpublished bitbucket.org/dchapes/random/cryptoseed

func randomSeed() int64 {
	var buf [8]byte
	if _, err := crand.Read(buf[:]); err != nil {
		return time.Now().UnixNano() // Fallback
	}
	var x uint64
	for _, b := range buf {
		x <<= 8
		x |= uint64(b)
	}
	return int64(x)
}
