package accrete

import (
	"fmt"
	"io"
	"math"
)

// A System represents an entire stellar system with all its planets.
//
// TODO(x): export some fields and/or provide accessor methods.
type System struct {
	stellarMassRatio       float64
	stellarLuminosityRatio float64
	mainSeqLife            float64
	age                    float64
	r_ecosphere            float64
	r_greenhouse           float64
	resonance              bool
	Planets                []*Planet
}

// GenerateStellarSystem generates a stellar system.
// If `log` is non-nil verbose logs of proggress are written to it.
func GenerateStellarSystem(log LogFn) *System {
	z := newAccretor(log)
	sys := new(System)

	sys.stellarMassRatio = random(0.6, 1.3)
	sys.stellarLuminosityRatio = luminosity(sys.stellarMassRatio)
	outerDustLimit := stellarDustLimit(sys.stellarMassRatio)
	sys.Planets = z.distPlanetaryMasses(sys.stellarMassRatio, sys.stellarLuminosityRatio, 0.0, outerDustLimit)
	sys.mainSeqLife = 1.0E10 * (sys.stellarMassRatio / sys.stellarLuminosityRatio)
	if sys.mainSeqLife >= 6.0E9 {
		sys.age = random(1.0E9, 6.0E9)
	} else {
		sys.age = random(1.0E9, sys.mainSeqLife)
	}
	sys.r_ecosphere = sqrt(sys.stellarLuminosityRatio)
	sys.r_greenhouse = sys.r_ecosphere * greenhousEffectConstant
	for _, p := range sys.Planets {
		orbitalZone := sys.orbitalZone(p.a)
		if p.gasGiant {
			p.density = sys.empiricalDensity(p.mass, p.a, p.gasGiant)
			p.radius = volumeRadius(p.mass, p.density)
		} else {
			p.radius = kothariRadius(p.mass, p.gasGiant, orbitalZone)
			p.density = volumeDensity(p.mass, p.radius)
		}
		p.orbitalPeriod = period(p.a, p.mass, sys.stellarMassRatio)
		p.day = sys.dayLength(p.mass, p.radius, p.e,
			p.density, p.a,
			p.orbitalPeriod, p.gasGiant)
		p.resonantPeriod = sys.resonance
		p.axialTilt = inclination(p.a)
		p.escapeVelocity = escapeVelocity(p.mass, p.radius)
		p.surfaceAcceleration = acceleration(p.mass, p.radius)
		p.rmsVelocity = rmsVelocity(molecularNitrogen, p.a)
		p.molecularWeight = moleculeLimit(p.mass, p.radius)
		if p.gasGiant {
			infinity := math.Inf(1)
			p.surfaceGravity = infinity
			p.greenhouseEffect = false
			p.volatileGasInventory = infinity
			p.surfacePressure = infinity
			p.boilingPoint = infinity
			p.hydrosphere = infinity
			p.albedo = about(gasGiantAlbedo, 0.1)
			p.surfaceTemp = infinity
		} else {
			p.surfaceGravity = gravity(p.surfaceAcceleration)
			p.greenhouseEffect = grnhouse(orbitalZone, p.a, sys.r_greenhouse)
			p.volatileGasInventory = volumeInventory(p.mass, p.escapeVelocity, p.rmsVelocity, sys.stellarMassRatio, orbitalZone, p.greenhouseEffect)
			p.surfacePressure = pressure(p.volatileGasInventory, p.radius, p.surfaceGravity)
			if p.surfacePressure == 0.0 {
				p.boilingPoint = 0.0
			} else {
				p.boilingPoint = boilingPoint(p.surfacePressure)
			}
			sys.iterateSurfaceTemp(p)
		}
	}
	return sys
}

// XXX

// Starform calls GenerateStellarSystem and then DisplaySystem.
func Starform(w io.Writer, lisp, verbose bool, seed int64) error {
	// XXX
	seed = seedRNG(seed)

	var log LogFn
	if verbose {
		if lisp {
			log = func(format string, v ...interface{}) {
				fmt.Fprintf(w, ";"+format, v...)
			}
		} else {
			log = func(format string, v ...interface{}) {
				fmt.Fprintf(w, format, v...)
			}
		}
	}

	var format string
	if lisp {
		format = "(Accrete-go %s) ; seed: 0x%.8x\n"
	} else {
		format = "Accrete - go-V%s; seed=0x%.8x\n"
	}
	if _, err := fmt.Fprintf(w, format, "3.0", seed); err != nil {
		return err
	}
	sys := GenerateStellarSystem(log)
	return sys.DisplaySystem(w, lisp)
}
