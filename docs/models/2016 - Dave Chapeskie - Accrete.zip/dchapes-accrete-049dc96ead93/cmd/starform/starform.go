package main

import (
	"flag"
	"log"
	"os"

	"bitbucket.org/dchapes/accrete"
)

func main() {
	lisp := flag.Bool("l", false, "set lisp output")
	verbose := flag.Bool("v", false, "be verbose")
	seed := flag.Int64("s", 0, "set random seed")
	flag.Parse()

	if err := accrete.Starform(os.Stdout, *lisp, *verbose, *seed); err != nil {
		log.Fatal(err)
	}
}
