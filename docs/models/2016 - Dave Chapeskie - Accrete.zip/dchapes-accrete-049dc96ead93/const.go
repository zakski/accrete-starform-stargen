package accrete

import "math"

const (
	π                               = math.Pi
	eccentricityCoeff               = 0.077    // Dole's was 0.077
	protoplanetMass                 = 1.0E-15  // Units of solar masses
	changeInEarthAngualVelocity     = -1.3E-15 // Units of radians/sec/year
	solarMassInGrams                = 1.989E33 // Units of grams
	earthMassInGrams                = 5.977E27 // Units of grams
	earthRadius                     = 6.378E8  // Units of cm
	earthDensity                    = 5.52     // Units of g/cc
	kmEarthRadius                   = 6378.0   // Units of km
	earthAcceleration               = 981.0    // Units of cm/sec2
	earthAxialTilt                  = 23.4     // Units of degrees
	earthExosphereTemp              = 1273.0   // Units of degrees Kelvin
	sunMassInEarthMasses            = 332775.64
	earthEffectiveTemp              = 255.0 // Units of degrees Kelvin
	earthAlbedo                     = 0.3
	cloudCoverageFactor             = 1.839E-8 // Km2/kg
	earthWaterMassPerArea           = 3.83E15  // grams per square km
	earthSurfacePressureInMillibars = 1000.0
	earthConvectionFactor           = 0.43    // from Hart, eq.20
	freezingPointOfWater            = 273.0   // Units of degrees Kelvin
	daysInYear                      = 365.256 // Earth days per Earth year
	gassRetentionThreshold          = 5.0     // ratio of esc vel to RMS vel
	gasGiantAlbedo                  = 0.5     // albedo of a gas giant
	cloudAlbedo                     = 0.52
	rockyAirlessAlbedo              = 0.07
	rockyAlbedo                     = 0.15
	waterAlbedo                     = 0.04
	iceAirlessAlbedo                = 0.5
	iceAlbedo                       = 0.7
	secondsPerHour                  = 3600
	cmPerAu                         = 1.495978707E13 // number of cm in an AU
	cmPerKm                         = 1E5            // number of cm in a km
	kmPerAu                         = cmPerAu / cmPerKm
	cmPerMeter                      = 100
	millibarsPerBar                 = 1000
	kelvinCelciusOffset             = 273
	gravitationalConstant           = 6.672E-8 // units of dyne cm2/gram2
	greenhousEffectConstant         = 0.93     // affects inner radius..
	molarGasConstant                = 8314.41  // units: g*m2/ = sec2*K*mol
	k                               = 50       // K = gas/dust ratio
	b                               = 1.2E-5   // Used in Crit_mass calc
	dustDensityCoeff                = 2E-3     // A in Dole's paper
	alpha                           = 5        // Used in density calcs
	n                               = 3        // Used in density calcs
	j                               = 1.46E-19 // Used in day-length calcs  = cm2/sec2 g

	//  Now for a few molecular weights (used for RMS velocity calcs):
	//  This table is from Dole's book "Habitable Planets for Man", p. 38

	//atomicHydrogen    = 1.0   // H
	//molecularHydrogen = 2.0   // H2
	//helium            = 4.0   // He
	//atomicNitrogen    = 14.0  // N
	//atomicOxygen      = 16.0  // O
	//methane           = 16.0  // CH4
	//ammonia           = 17.0  // NH3
	waterVapor = 18.0 // H2O
	//neon              = 20.2  // Ne
	molecularNitrogen = 28.0 // N2
	//carbonMonoxide    = 28.0  // CO
	//nitricOxide       = 30.0  // NO
	//molecularOxygen   = 32.0  // O2
	//hydrogenSulphide  = 34.1  // H2S
	//argon             = 39.9  // Ar
	//carbonDioxide     = 44.0  // CO2
	//nitrousOxide      = 44.0  // N2O
	//nitrogenDioxide   = 46.0  // NO2
	//ozone             = 48.0  // O3
	//sulphurDioxide    = 64.1  // SO2
	//sulphurTrioxide   = 80.1  // SO3
	//krypton           = 83.8  // Kr
	//xenon             = 131.3 // Xe
)
