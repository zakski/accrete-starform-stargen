package accrete

import (
	"fmt"
	"io"
)

// TODO redo as a Go fmt.Formatter?

// eng formats d in engineering notation with precision p.
func eng(d float64, p int) string {
	const (
		maxExpDigits = 3
		maxManDigits = 20
	)

	mansign := '+'
	expsign := '+'
	if p > maxManDigits {
		p = maxManDigits
	}
	if p < 3 {
		p = 3
	}
	p--
	if d < 0.0 {
		mansign = '-'
		d = -d
	}
	var mantissa float64
	var exponent int
	if d != 0.0 {
		exponent = int(log10(d))
		if exponent == 0 && d < 1.0 {
			// C's log10 sometimes lies… is this needed with Go?
			exponent--
			p--
		}
		if exponent < 0 {
			expsign = '-'
			exponent--
		}
		mantissa = d / pow(10.0, float64(exponent))
		if exponent < 0 {
			exponent = -exponent
		}
		for exponent%3 != 0 {
			mantissa *= 10.0
			p--
			if expsign == '-' {
				exponent++
			} else {
				exponent--
			}
		}
	}
	return fmt.Sprintf("%c%*.*fe%c%*.*d", mansign, p, p, mantissa,
		expsign, maxExpDigits, maxExpDigits, exponent)
}

func (sys *System) textDescribeSystem(w io.Writer) {
	fmt.Fprintf(w, "                         SYSTEM  CHARACTERISTICS\n")
	fmt.Fprintf(w, "Stellar mass: %4.2f solar masses\n", sys.stellarMassRatio)
	fmt.Fprintf(w, "Stellar luminosity: %4.2f\n", sys.stellarLuminosityRatio)
	fmt.Fprintf(w, "Age: %5.3f billion years  (%5.3f billion left on main sequence)\n",
		sys.age/1.0E9, (sys.mainSeqLife-sys.age)/1.0E9)
	fmt.Fprintf(w, "Habitable ecosphere radius: %3.3f AU\n", sys.r_ecosphere)
	fmt.Fprintf(w, "\n")
	fmt.Fprintf(w, "Planets present at:\n")
	for i, p := range sys.Planets {
		fmt.Fprintf(w, "%d\t%7.3f \t AU\n", i+1, p.a)
	}
	fmt.Fprintf(w, "\n\n\n")
	for i, p := range sys.Planets {
		fmt.Fprintf(w, "Planet %d\t", i+1)
		if p.gasGiant {
			fmt.Fprintf(w, "*gas giant*\n")
		} else {
			fmt.Fprintf(w, "\n")
		}
		if int(p.day) == int(p.orbitalPeriod*24.0) {
			fmt.Fprintf(w, "Planet is tidally locked with one face to star.\n")
		}
		if p.resonantPeriod {
			fmt.Fprintf(w, "Planet's rotation is in a resonant spin lock with the star\n")
		}
		fmt.Fprintf(w, "   Distance from primary star:\t%5.3f\tAU\n", p.a)
		fmt.Fprintf(w, "   Mass:\t\t\t%5.3f\tEarth masses\n", p.mass*sunMassInEarthMasses)
		if !p.gasGiant {
			fmt.Fprintf(w, "   Surface gravity:\t\t%4.2f\tEarth gees\n", p.surfaceGravity)
			fmt.Fprintf(w, "   Surface pressure:\t\t%5.3f\tEarth atmospheres", p.surfacePressure/1000.0)
			if p.greenhouseEffect && p.surfacePressure > 0.0 {
				fmt.Fprintf(w, "\tGREENHOUSE EFFECT\n")
			} else {
				fmt.Fprintf(w, "\n")
			}
			fmt.Fprintf(w, "   Surface temperature:\t\t%4.2f\tdegrees Celcius\n", p.surfaceTemp-kelvinCelciusOffset)
		}
		fmt.Fprintf(w, "   Equatorial radius:\t\t%3.1f\tKm\n", p.radius)
		fmt.Fprintf(w, "   Density:\t\t\t%5.3f\tgrams/cc\n", p.density)
		fmt.Fprintf(w, "   Eccentricity of orbit:\t%5.3f\n", p.e)
		fmt.Fprintf(w, "   Escape Velocity:\t\t%4.2f\tKm/sec\n", p.escapeVelocity/cmPerKm)
		fmt.Fprintf(w, "   Molecular weight retained:\t%4.2f and above\n", p.molecularWeight)
		fmt.Fprintf(w, "   Surface acceleration:\t%4.2f\tcm/sec2\n", p.surfaceAcceleration)
		fmt.Fprintf(w, "   Axial tilt:\t\t\t%d\tdegrees\n", p.axialTilt)
		fmt.Fprintf(w, "   Planetary albedo:\t\t%5.3f\n", p.albedo)
		fmt.Fprintf(w, "   Length of year:\t\t%4.2f\tdays\n", p.orbitalPeriod)
		fmt.Fprintf(w, "   Length of day:\t\t%4.2f\thours\n", p.day)
		if !p.gasGiant {
			fmt.Fprintf(w, "   Boiling point of water:\t%3.1f\tdegrees Celcius\n", p.boilingPoint-kelvinCelciusOffset)
			fmt.Fprintf(w, "   Hydrosphere percentage:\t%4.2f\n", p.hydrosphere*100.0)
			fmt.Fprintf(w, "   Cloud cover percentage:\t%4.2f\n", p.cloudCover*100)
			fmt.Fprintf(w, "   Ice cover percentage:\t%4.2f\n", p.iceCover*100)
		}
		fmt.Fprintf(w, "\n\n")
	}
}

// XXX
func b2i(b bool) int {
	if b {
		return 1
	}
	return 0
}

func (sys *System) lispDescribeSystem(w io.Writer) {
	const (
		OP = "("
		CP = ")"
	)
	fmt.Fprintf(w, "%splanetary-system\n", OP)
	fmt.Fprintf(w, " %ssun\n", OP)
	fmt.Fprintf(w, "  %smass %s%s ; kg\n",
		OP, eng(sys.stellarMassRatio*solarMassInGrams/1000.0, 6), CP)
	fmt.Fprintf(w, "  %sluminosity %s%s ; * SOL luminosity\n",
		OP, eng(sys.stellarLuminosityRatio, 6), CP)
	fmt.Fprintf(w, "  %slifetime %s%s ; years\n",
		OP, eng(sys.mainSeqLife, 6), CP)
	fmt.Fprintf(w, "  %scurrent-age %s%s ; years\n",
		OP, eng(sys.age, 6), CP)
	fmt.Fprintf(w, "  %secosphere-radius %s%s ; km\n",
		OP, eng(sys.r_ecosphere*kmPerAu, 6), CP)
	fmt.Fprintf(w, " %s\n", CP)
	for i, p := range sys.Planets {
		fmt.Fprintf(w, " %splanet ; #%d\n", OP, i+1)
		fmt.Fprintf(w, "  ; boolean:\n")
		fmt.Fprintf(w, "  %sis-gas-giant %d%s\n", OP, b2i(p.gasGiant), CP)
		fmt.Fprintf(w, "  ; orbital statistics:\n")
		fmt.Fprintf(w, "  %smean-orbit-radius %s%s ; km\n",
			OP, eng(p.a*kmPerAu, 6), CP)
		fmt.Fprintf(w, "  %sorbit-eccentricity %s%s\n",
			OP, eng(p.e, 6), CP)
		fmt.Fprintf(w, "  %saxial-tilt %d%s ; degrees\n",
			OP, p.axialTilt, CP)
		fmt.Fprintf(w, "  %sorbital-period %s%s ; Earth days\n",
			OP, eng(p.orbitalPeriod, 6), CP)
		fmt.Fprintf(w, "  %srotation-period %s%s ; Earth hours\n",
			OP, eng(p.day, 6), CP)
		fmt.Fprintf(w, "  %sis-resonant %d%s\n", OP, b2i(p.resonantPeriod), CP)
		fmt.Fprintf(w, "  ; planetary measurements:\n")
		fmt.Fprintf(w, "  %smass %s%s ; kg\n",
			OP, eng(p.mass*solarMassInGrams/1000.0, 6), CP)
		fmt.Fprintf(w, "  %sequatorial-radius %s%s ; km\n",
			OP, eng(p.radius, 6), CP)
		fmt.Fprintf(w, "  %sdensity %s%s ; g/cm3\n",
			OP, eng(p.density, 6), CP)
		fmt.Fprintf(w, "  ; planetary environment:\n")
		fmt.Fprintf(w, "  %sescape-velocity %s%s ; km/sec\n",
			OP, eng(p.escapeVelocity/cmPerKm, 6), CP)
		fmt.Fprintf(w, "  %smin-molecular-weight-retained %s%s\n",
			OP, eng(p.molecularWeight, 3), CP)
		fmt.Fprintf(w, "  %ssurface-acceleration %s%s ; cm/sec2\n",
			OP, eng(p.surfaceAcceleration, 6), CP)
		if !p.gasGiant {
			fmt.Fprintf(w, "  %ssurface-gravity %s%s ; Earth gees\n",
				OP, eng(p.surfaceGravity, 3), CP)
			fmt.Fprintf(w, "  %sh2o-boils %s%s ; degrees celcius\n",
				OP,
				eng(p.boilingPoint-kelvinCelciusOffset, 3),
				CP)
			fmt.Fprintf(w, "  %ssurface-pressure %s%s ; Earth atmospheres\n",
				OP, eng(p.surfacePressure/1000.0, 3), CP)
			if p.greenhouseEffect && p.surfacePressure > 0.0 {
				fmt.Fprintf(w, "  %sgreenhouse 1%s\n", OP, CP)
			} else {
				fmt.Fprintf(w, "  %sgreenhouse 0%s\n", OP, CP)
			}
			fmt.Fprintf(w, "  %ssurface-temperature %s%s ; degrees celcius\n",
				OP, eng(p.surfaceTemp-kelvinCelciusOffset, 3), CP)
			fmt.Fprintf(w, "  %shydrosphere %s%s\n",
				OP, eng(p.hydrosphere, 3), CP)
			fmt.Fprintf(w, "  %scloud-cover %s%s\n",
				OP, eng(p.cloudCover, 3), CP)
			fmt.Fprintf(w, "  %sice-cover %s%s\n",
				OP, eng(p.iceCover, 3), CP)
		}
		fmt.Fprintf(w, "  %salbedo %s%s\n",
			OP, eng(p.albedo, 3), CP)
		fmt.Fprintf(w, " %s\n", CP)
	}
	fmt.Fprintf(w, "%s\n", CP)
}

// DisplaySystem writes a text discription of the system to w.
// If lisp is true the output is in lisp format.
func (sys *System) DisplaySystem(w io.Writer, lisp bool) error {
	ew := errWriter{w: w}
	switch {
	case lisp:
		sys.lispDescribeSystem(ew)
	default:
		sys.textDescribeSystem(ew)
	}
	return ew.err
}

// errWriter is a simple error caching io.Writer that
// allows us to otherwise ignore write errors
type errWriter struct {
	w   io.Writer
	err error
}

func (ew errWriter) Write(p []byte) (int, error) {
	if ew.err != nil {
		return 0, ew.err
	}
	var n int
	n, ew.err = ew.w.Write(p)
	return n, ew.err
}
