package accrete

import "sort"

type accretor struct {
	r_inner           float64
	r_outer           float64
	reducedMass       float64
	dustDensity       float64
	cloudEccentricity float64
	dustLeft          bool
	dustBands         []*dust
	log               LogFn
}

// LogFn is a function used for logging progress.
type LogFn func(format string, v ...interface{})

func newAccretor(log LogFn) *accretor {
	if log == nil {
		log = func(string, ...interface{}) {}
	}
	return &accretor{log: log}
}

// TODO: pick a reciever name better than `z`

func (z *accretor) setInitialConditions(innerDustLimit, outerDustLimit float64) {
	if len(z.dustBands) > 0 {
		z.dustBands = z.dustBands[:0]
	}
	z.dustBands = append(z.dustBands, &dust{
		innerEdge:   innerDustLimit,
		outerEdge:   outerDustLimit,
		dustPresent: true,
		gasPresent:  true,
	})
	z.dustLeft = true
	z.cloudEccentricity = 0.2
}

func stellarDustLimit(stellarMassRatio float64) float64 {
	return 200.0 * pow(stellarMassRatio, 1.0/3.0)
}

func nearestPlanet(stellarMassRatio float64) float64 {
	return 0.3 * pow(stellarMassRatio, 1.0/3.0)
}

func farthestPlanet(stellarMassRatio float64) float64 {
	return 50.0 * pow(stellarMassRatio, 1.0/3.0)
}

func (z *accretor) innerEffectLimit(a, e, mass float64) float64 {
	return a * (1.0 - e) * (1.0 - mass) / (1.0 + z.cloudEccentricity)
}

func (z *accretor) outerEffectLimit(a, e, mass float64) float64 {
	return a * (1.0 + e) * (1.0 + mass) / (1.0 - z.cloudEccentricity)
}

func (z *accretor) dustAvailable(insideRange, outsideRange float64) bool {
	for _, d := range z.dustBands {
		if d.outerEdge < insideRange {
			continue
		}
		if d.innerEdge >= outsideRange {
			break
		}
		if d.dustPresent {
			return true
		}
	}
	return false
}

func (z *accretor) updateDustLanes(min, max, mass, criticalMass,
	bodyInnerBound, bodyOuterBound float64) {

	gas := mass <= criticalMass
	newBands := make([]*dust, 0, len(z.dustBands)+2)
	for _, db := range z.dustBands {
		switch {
		case db.innerEdge < min && db.outerEdge > max:
			next := &dust{
				innerEdge:   min,
				outerEdge:   max,
				gasPresent:  db.gasPresent && gas,
				dustPresent: false,
			}
			next2 := &dust{
				innerEdge:   max,
				outerEdge:   db.outerEdge,
				gasPresent:  db.gasPresent,
				dustPresent: db.dustPresent,
			}
			db.outerEdge = min
			newBands = append(newBands, db, next, next2)
		case db.innerEdge < max && db.outerEdge > max:
			next := &dust{
				dustPresent: db.dustPresent,
				gasPresent:  db.gasPresent,
				outerEdge:   db.outerEdge,
				innerEdge:   max,
			}
			db.outerEdge = max
			db.gasPresent = db.gasPresent && gas
			db.dustPresent = false
			newBands = append(newBands, db, next)
		case db.innerEdge < min && db.outerEdge > min:
			next := &dust{
				dustPresent: false,
				gasPresent:  db.gasPresent && gas,
				outerEdge:   db.outerEdge,
				innerEdge:   min,
			}
			db.outerEdge = min
			newBands = append(newBands, db, next)
		case db.innerEdge >= min && db.outerEdge <= max:
			if db.gasPresent {
				db.gasPresent = gas
			}
			db.dustPresent = false
			newBands = append(newBands, db)
		case db.outerEdge < min || db.innerEdge > max:
			newBands = append(newBands, db)
		default:
			panic("internal error")
		}
	}

	z.dustLeft = false
	z.dustBands = z.dustBands[:0]
	var prev *dust
	for _, db := range newBands {
		if prev != nil &&
			prev.dustPresent == db.dustPresent &&
			prev.gasPresent == db.gasPresent {
			prev.outerEdge = db.outerEdge
			continue
		}
		if db.dustPresent &&
			db.outerEdge >= bodyInnerBound &&
			db.innerEdge <= bodyOuterBound {
			z.dustLeft = true
		}
		z.dustBands = append(z.dustBands, db)
		prev = db
	}
}

func (z *accretor) collectDust(lastMass, a, e, criticalMass float64) float64 {
	var fn func(int) float64
	fn = func(i int) float64 {
		if i >= len(z.dustBands) {
			return 0.0
		}
		db := z.dustBands[i]
		z.reducedMass = pow(lastMass/(1.0+lastMass), 1.0/4.0)
		z.r_inner = z.innerEffectLimit(a, e, z.reducedMass)
		z.r_outer = z.outerEffectLimit(a, e, z.reducedMass)
		if z.r_inner < 0.0 {
			z.r_inner = 0.0
		}
		tmpDensity := 0.0
		if db.dustPresent {
			tmpDensity = z.dustDensity
		}
		massDensity := tmpDensity
		if lastMass >= criticalMass && db.gasPresent {
			massDensity = k * tmpDensity /
				(1.0 + sqrt(criticalMass/lastMass)*(k-1.0))
		}
		if db.outerEdge <= z.r_inner ||
			db.innerEdge >= z.r_outer {
			return fn(i + 1)
		}
		bandwidth := z.r_outer - z.r_inner
		tmp1 := z.r_outer - db.outerEdge
		if tmp1 < 0.0 {
			tmp1 = 0.0
		}
		width := bandwidth - tmp1
		tmp2 := db.innerEdge - z.r_inner
		if tmp2 < 0.0 {
			tmp2 = 0.0
		}
		width -= tmp2
		tmp := 4.0 * π * pow(a, 2.0) * z.reducedMass *
			(1.0 - e*(tmp1-tmp2)/bandwidth)
		volume := tmp * width
		return volume*massDensity + fn(i+1)
	}
	return fn(0)
}

//   Orbital radius is in AU, eccentricity is unitless, and the stellar
//  luminosity ratio is with respect to the sun.  The value returned is the
//  mass at which the planet begins to accrete gas as well as dust, and is
//  in units of solar masses.
func criticalLimit(orbitalRadius, eccentricity, stellarLuminosityRatio float64) float64 {
	perihelion := orbitalRadius - orbitalRadius*eccentricity
	tmp := perihelion * sqrt(stellarLuminosityRatio)
	return b * pow(tmp, -0.75)
}

func (z *accretor) accreteDust(seedMass *float64, a, e, criticalMass,
	bodyInnerBound, bodyOuterBound float64) {

	newMass := *seedMass
	for {
		prevMass := newMass
		newMass = z.collectDust(newMass, a, e, criticalMass)
		if newMass-prevMass < 0.0001*prevMass {
			break
		}
	}
	*seedMass += newMass
	z.updateDustLanes(z.r_inner, z.r_outer, *seedMass, criticalMass, bodyInnerBound, bodyOuterBound)
}

func (z *accretor) coalescePlanetesimals(planets []*Planet,
	a, e, mass, criticalMass,
	stellarLuminosityRatio,
	bodyInnerBound, bodyOuterBound float64) []*Planet {

	for _, p := range planets {
		var dist1, dist2 float64
		tmp := p.a - a
		if tmp > 0.0 {
			dist1 = a*(1.0+e)*(1.0+z.reducedMass) - a
			// x aphelion
			z.reducedMass = pow(p.mass/(1.0+p.mass), 1.0/4.0)
			dist2 = p.a - p.a*(1.0-p.e)*(1.0-z.reducedMass)
		} else {
			dist1 = a - a*(1.0-e)*(1.0-z.reducedMass)
			// x perihelion
			z.reducedMass = pow(p.mass/(1.0+p.mass), 1.0/4.0)
			dist2 = p.a*(1.0+p.e)*(1.0+z.reducedMass) - p.a
		}
		if abs(tmp) <= abs(dist1) || abs(tmp) <= abs(dist2) {
			z.log("Collision between two planetesimals!\n")
			a3 := (p.mass + mass) / (p.mass/p.a + mass/a)
			tmp = p.mass * sqrt(p.a) * sqrt(1.0-pow(p.e, 2.0))
			tmp += mass * sqrt(a) * sqrt(sqrt(1.0-pow(e, 2.0)))
			tmp /= ((p.mass + mass) * sqrt(a3))
			tmp = 1.0 - pow(tmp, 2.0)
			if tmp < 0.0 || tmp >= 1.0 {
				tmp = 0.0
			}
			e = sqrt(tmp)
			tmp = p.mass + mass
			z.accreteDust(&tmp, a3, e, stellarLuminosityRatio,
				bodyInnerBound, bodyOuterBound)
			p.a = a3
			p.e = e
			p.mass = tmp
			return planets
		}
	}

	i := sort.Search(len(planets), func(i int) bool {
		return planets[i].a >= a
	})
	// insert new planet at i
	planets = append(planets, nil)
	copy(planets[i+1:], planets[i:])
	planets[i] = &Planet{
		a:        a,
		e:        e,
		gasGiant: mass >= criticalMass,
		mass:     mass,
	}
	return planets
}

func (z *accretor) distPlanetaryMasses(stellarMassRatio,
	stellarLuminosityRatio, innerDust, outerDust float64) []*Planet {

	var planets []*Planet
	z.setInitialConditions(innerDust, outerDust)
	planetInnerBound := nearestPlanet(stellarMassRatio)
	planetOuterBound := farthestPlanet(stellarMassRatio)
	for z.dustLeft {
		a := random(planetInnerBound, planetOuterBound)
		e := randomEccentricity()
		mass := protoplanetMass
		z.log("Checking %g AU.\n", a)
		if z.dustAvailable(z.innerEffectLimit(a, e, mass),
			z.outerEffectLimit(a, e, mass)) {
			z.log(".. Injecting protoplanet.\n")
			z.dustDensity = dustDensityCoeff * sqrt(stellarMassRatio) *
				exp(-alpha*pow(a, 1.0/n))
			criticalMass := criticalLimit(a, e, stellarLuminosityRatio)
			z.accreteDust(&mass, a, e, criticalMass,
				planetInnerBound, planetOuterBound)
			if mass != 0.0 && mass != protoplanetMass {
				planets = z.coalescePlanetesimals(planets, a, e, mass, criticalMass,
					stellarLuminosityRatio,
					planetInnerBound, planetOuterBound)
			} else {
				z.log(".. failed due to large neighbor.\n")
			}
		} else {
			z.log(".. failed.\n")
		}
	}
	return planets
}
