package accrete

import "math"

func luminosity(massRatio float64) float64 {
	var n float64
	if massRatio < 1.0 {
		n = 1.75*(massRatio-0.1) + 3.325
	} else {
		n = 0.5*(2.0-massRatio) + 4.4
	}
	return pow(massRatio, n)
}

//   This function, given the orbital radius of a planet in AU, returns
//   the orbital 'zone' of the particle.
func (sys *System) orbitalZone(orbitalRadius float64) int {
	switch {
	case orbitalRadius < 4.0*sqrt(sys.stellarLuminosityRatio):
		return 1
	case orbitalRadius >= 4.0*sqrt(sys.stellarLuminosityRatio) && orbitalRadius < 15.0*sqrt(sys.stellarLuminosityRatio):
		return 2
	default:
		return 3
	}
}

//   The mass is in units of solar masses, and the density is in units
//   of grams/cc.  The radius returned is in units of km.
func volumeRadius(mass, density float64) float64 {
	mass *= solarMassInGrams
	volume := mass / density
	return pow(3.0*volume/(4.0*π), 1.0/3.0) / cmPerKm
}

//   Returns the radius of the planet in kilometers.
//   The mass passed in is in units of solar masses.
//   This formula is listed as eq.9 in Fogg's article, although some typos
//   crop up in that eq.  See "The Internal Constitution of Planets", by
//   Dr. D. S. Kothari, Mon. Not. of the Royal Astronomical Society, vol 96
//   pp.833-843, 1936 for the derivation.  Specifically, this is Kothari's
//   eq.23, which appears on page 840.
func kothariRadius(mass float64, giant bool, zone int) float64 {
	const (
		a1_20  = 6.485E12  // All units are in cgs system.
		a2_20  = 4.0032E-8 //   ie: cm, g, dynes, etc.
		beta20 = 5.71E12
	)

	var atomicWeight, atomicNum float64

	switch zone {
	case 1:
		if giant {
			atomicWeight = 9.5
			atomicNum = 4.5
		} else {
			atomicWeight = 15.0
			atomicNum = 8.0
		}
	case 2:
		if giant {
			atomicWeight = 2.47
			atomicNum = 2.0
		} else {
			atomicWeight = 10.0
			atomicNum = 5.0
		}
	default:
		if giant {
			atomicWeight = 7.0
			atomicNum = 4.0
		} else {
			atomicWeight = 10.0
			atomicNum = 5.0
		}
	}
	temp := atomicWeight * atomicNum
	temp = 2.0 * beta20 * pow(solarMassInGrams, 1.0/3.0) / (a1_20 * pow(temp, 1.0/3.0))
	temp2 := a2_20 * pow(atomicWeight, 4.0/3.0) * pow(solarMassInGrams, 2.0/3.0)
	temp2 *= pow(mass, 2.0/3.0)
	temp2 /= a1_20 * pow2(atomicNum)
	temp2 += 1.0
	temp /= temp2
	temp *= pow(mass, 1.0/3.0) / cmPerKm
	return temp
}

//  The mass passed in is in units of solar masses, and the orbital radius
//  is in units of AU.  The density is returned in units of grams/cc.
func (sys *System) empiricalDensity(mass, orbitalRadius float64, gasGiant bool) float64 {
	temp := pow(mass*sunMassInEarthMasses, 1.0/8.0)
	temp *= pow1_4(sys.r_ecosphere / orbitalRadius)
	if gasGiant {
		return temp * 1.2
	}
	return temp * 5.5
}

//  The mass passed in is in units of solar masses, and the equatorial
//  radius is in km.  The density is returned in units of grams/cc.
func volumeDensity(mass, equatorialRadius float64) float64 {
	mass *= solarMassInGrams
	equatorialRadius *= cmPerKm
	volume := 4.0 * π * pow3(equatorialRadius) / 3.0
	return mass / volume
}

//  The separation is in units of AU, and both masses are in units of solar
//  masses.  The period returned is in terms of Earth days.
func period(separation, smallMass, largeMass float64) float64 {
	periodInYears := sqrt(pow3(separation) / (smallMass + largeMass))
	return periodInYears * daysInYear
}

//   Fogg's information for this routine came from Dole "Habitable Planets
// for Man", Blaisdell Publishing Company, NY, 1964.  From this, he came
// up with his eq.12, which is the equation for the 'baseAngularVelocity'
// below.  He then used an equation for the change in angular velocity per
// time (dw/dt) from P. Goldreich and S. Soter's paper "Q in the Solar
// System" in Icarus, vol 5, pp.375-389 (1966).  Using as a comparison the
// change in angular velocity for the Earth, Fogg has come up with an
// approximation for our new planet (his eq.13) and take that into account.
// This is used to find 'changeInAngularVelocity' below.
//
//   Input parameters are mass (in solar masses), radius (in Km), orbital
// period (in days), orbital radius (in AU), density (in g/cc),
// eccentricity, and whether it is a gas giant or not.
//   The length of the day is returned in units of hours.
func (sys *System) dayLength(mass, radius, eccentricity, density,
	orbitalRadius, orbitalPeriod float64, giant bool) float64 {

	stopped := false
	sys.resonance = false
	var k2 float64
	if giant {
		k2 = 0.24
	} else {
		k2 = 0.33
	}
	planetaryMassInGrams := mass * solarMassInGrams
	equatorialRadiusInCm := radius * cmPerKm
	yearInHours := orbitalPeriod * 24.0
	baseAngularVelocity := sqrt(2.0 * j * planetaryMassInGrams /
		(k2 * pow2(equatorialRadiusInCm)))
	//  This next calculation determines how much the planet's rotation is
	//  slowed by the presence of the star.
	changeInAngularVelocity := changeInEarthAngualVelocity *
		(density / earthDensity) *
		(equatorialRadiusInCm / earthRadius) *
		(earthMassInGrams / planetaryMassInGrams) *
		pow(sys.stellarMassRatio, 2.0) *
		(1.0 / pow(orbitalRadius, 6.0))
	angularVelocity := baseAngularVelocity + changeInAngularVelocity*sys.age
	// Now we change from rad/sec to hours/rotation.
	var dayInHours float64
	if angularVelocity <= 0.0 {
		stopped = true
	} else {
		const radiansPerRotation = 2.0 * π
		dayInHours = radiansPerRotation / (secondsPerHour * angularVelocity)
	}
	if dayInHours >= yearInHours || stopped {
		if eccentricity > 0.1 {
			spinResonanceFactor := (1.0 - eccentricity) / (1.0 + eccentricity)
			sys.resonance = true
			return spinResonanceFactor * yearInHours
		}
		return yearInHours
	}
	return dayInHours
}

//   The orbital radius is expected in units of Astronomical Units (AU).
//   Inclination is returned in units of degrees.
func inclination(orbitalRadius float64) int {
	temp := int(pow(orbitalRadius, 0.2) * about(earthAxialTilt, 0.4))
	return temp % 360
}

//   This function implements the escape velocity calculation.  Note that
//  it appears that Fogg's eq.15 is incorrect.
//  The mass is in units of solar mass, the radius in kilometers, and the
//  velocity returned is in cm/sec.
func escapeVelocity(mass, radius float64) float64 {
	massInGrams := mass * solarMassInGrams
	radiusInCm := radius * cmPerKm
	return sqrt(2.0 * gravitationalConstant * massInGrams / radiusInCm)
}

//  This is Fogg's eq.16.  The molecular weight (usually assumed to be N2)
//  is used as the basis of the Root Mean Square (RMS) velocity of the
//  molecule or atom.  The velocity returned is in cm/sec.
func rmsVelocity(molecularWeight, orbitalRadius float64) float64 {
	exosphericTemp := earthExosphereTemp / pow2(orbitalRadius)
	return sqrt(3.0*molarGasConstant*exosphericTemp/molecularWeight) * cmPerMeter
}

//   This function returns the smallest molecular weight retained by the
//  body, which is useful for determining the atmosphere composition.
//  Orbital radius is in A.U.(ie: in units of the earth's orbital radius),
//  mass is in units of solar masses, and equatorial radius is in units of
//  kilometers.
func moleculeLimit(mass, equatorialRadius float64) float64 {
	ev := escapeVelocity(mass, equatorialRadius)
	return 3.0 * pow2(gassRetentionThreshold*cmPerMeter) * molarGasConstant * earthExosphereTemp / pow2(ev)
}

//   This function calculates the surface acceleration of a planet.  The
//  mass is in units of solar masses, the radius in terms of km, and the
//  acceleration is returned in units of cm/sec2.
func acceleration(mass, radius float64) float64 {
	return gravitationalConstant * (mass * solarMassInGrams) /
		pow2(radius*cmPerKm)
}

//   This function calculates the surface gravity of a planet.  The
//  acceleration is in units of cm/sec2, and the gravity is returned in
//  units of Earth gravities.
func gravity(acceleration float64) float64 {
	return acceleration / earthAcceleration
}

//  Note that if the orbital radius of the planet is greater than or equal
//  to R_inner, 99% of it's volatiles are assumed to have been deposited in
//  surface reservoirs (otherwise, it suffers from the greenhouse effect).
func grnhouse(zone int, orbitalRadius, r_greenhouse float64) bool {
	return orbitalRadius < r_greenhouse && zone == 1
}

//  This implements Fogg's eq.17.  The 'inventory' returned is unitless.
func volumeInventory(mass, escapeVelocity, rmsVelocity, stellarMass float64, zone int, greenhouseEffect bool) float64 {
	velocityRatio := escapeVelocity / rmsVelocity
	if velocityRatio >= gassRetentionThreshold {
		var proportionConst float64
		switch zone {
		case 1:
			proportionConst = 100000.0
		case 2:
			proportionConst = 75000.0
		case 3:
			proportionConst = 250.0
		default:
			panic("Error: orbital zone not initialized correctly!")
		}
		earthUnits := mass * sunMassInEarthMasses
		tmp1 := proportionConst * earthUnits / stellarMass
		tmp2 := about(tmp1, 0.2)
		if !greenhouseEffect {
			tmp2 /= 100.0
		}
		return tmp2
	}
	return 0.0
}

//  This implements Fogg's eq.18.  The pressure returned is in units of
//  millibars (mb).  The gravity is in units of Earth gravities, the radius
//  in units of kilometers.
func pressure(volatileGasInventory, equatorialRadius, gravity float64) float64 {
	equatorialRadius = kmEarthRadius / equatorialRadius
	return volatileGasInventory * gravity / pow2(equatorialRadius)
}

//   This function returns the boiling point of water in an atmosphere of
//   pressure 'surfacePressure', given in millibars.  The boiling point is
//   returned in units of Kelvin.  This is Fogg's eq.21.
func boilingPoint(surfacePressure float64) float64 {
	surfacePressureInBars := surfacePressure / millibarsPerBar
	return 1.0 / (math.Log(surfacePressureInBars)/-5050.5 + 1.0/373.0)
}

//   This function is Fogg's eq.22.  Given the volatile gas inventory and
//   planetary radius of a planet (in Km), this function returns the
//   fraction of the planet covered with water.
//   I have changed the function very slightly:  the fraction of Earth's
//   surface covered by water is 71%, not 75% as Fogg used.
func hydroFraction(volatileGasInventory, planetRadius float64) float64 {
	tmp := 0.71 * volatileGasInventory / 1000.0 * pow2(kmEarthRadius/planetRadius)
	if tmp >= 1.0 {
		tmp = 1.0
	}
	return tmp
}

//   Given the surface temperature of a planet (in Kelvin), this function
//   returns the fraction of cloud cover available.  This is Fogg's eq.23.
//   See Hart in "Icarus" (vol 33, pp23 - 39, 1978) for an explanation.
//   This equation is Hart's eq.3.
//   I have modified it slightly using constants and relationships from
//   Glass's book "Introduction to Planetary Geology", p.46.
//   The 'CLOUD_COVERAGE_FACTOR' is the amount of surface area on Earth
//   covered by one Kg. of cloud.
func cloudFraction(surfaceTemp, smallestMWRetained, equatorialRadius, hydroFraction float64) float64 {
	const (
		q1_36 = 1.258E19 // grams
		q2_36 = 0.0698   // 1/Kelvin
	)
	if smallestMWRetained > waterVapor {
		return 0.0
	}
	surfaceArea := 4.0 * π * pow2(equatorialRadius)
	hydroMass := hydroFraction * surfaceArea * earthWaterMassPerArea
	waterVaporInKg := 1e-8 * hydroMass * exp(q2_36*(surfaceTemp-288.0))
	fraction := cloudCoverageFactor * waterVaporInKg / surfaceArea
	if fraction >= 1.0 {
		fraction = 1.0
	}
	return fraction
}

//   Given the surface temperature of a planet (in Kelvin), this function
//   returns the fraction of the planet's surface covered by ice.  This is
//   Fogg's eq.24.  See Hart[24] in Icarus vol.33, p.28 for an explanation.
//   I have changed a constant from 70 to 90 in order to bring it more in
//   line with the fraction of the Earth's surface covered with ice, which
//   is approximatly .016 (=1.6%).
func iceFraction(hydroFraction, surfaceTemp float64) float64 {
	if surfaceTemp > 328.0 {
		surfaceTemp = 328.0
	}
	tmp := pow((328.0-surfaceTemp)/90.0, 5.0)
	if tmp > 1.5*hydroFraction {
		tmp = 1.5 * hydroFraction
	}
	if tmp > 1.0 {
		tmp = 1.0
	}
	return tmp
}

//  This is Fogg's eq.19.  The ecosphere radius is given in AU, the orbital
//  radius in AU, and the temperature returned is in Kelvin.
func effectiveTemp(ecosphereRadius, orbitalRadius, albedo float64) float64 {
	return sqrt(ecosphereRadius/orbitalRadius) *
		pow1_4((1.0-albedo)/0.7) * earthEffectiveTemp
}

//  This is Fogg's eq.20, and is also Hart's eq.20 in his "Evolution of
//  Earth's Atmosphere" article.  The effective temperature given is in
//  units of Kelvin, as is the rise in temperature produced by the
//  greenhouse effect, which is returned.
func greenhouseRise(opticalDepth, effectiveTemp, surfacePressure float64) float64 {
	convectionFactor := earthConvectionFactor *
		pow1_4(surfacePressure/earthSurfacePressureInMillibars)
	return (pow1_4(1.0+0.75*opticalDepth) - 1.0) *
		effectiveTemp * convectionFactor
}

//   The surface temperature passed in is in units of Kelvin.
//   The cloud adjustment is the fraction of cloud cover obscuring each
//   of the three major components of albedo that lie below the clouds.
func planetAlbedo(waterFraction, cloudFraction, iceFraction, surfacePressure float64) float64 {
	rockFraction := 1.0 - waterFraction - iceFraction
	components := 0.0
	if waterFraction > 0.0 {
		components += 1.0
	}
	if iceFraction > 0.0 {
		components += 1.0
	}
	if rockFraction > 0.0 {
		components += 1.0
	}
	cloudAdjustment := cloudFraction / components
	if rockFraction >= cloudAdjustment {
		rockFraction -= cloudAdjustment
	} else {
		rockFraction = 0.0
	}
	if waterFraction > cloudAdjustment {
		waterFraction -= cloudAdjustment
	} else {
		waterFraction = 0.0
	}
	if iceFraction > cloudAdjustment {
		iceFraction -= cloudAdjustment
	} else {
		iceFraction = 0.0
	}
	cloudPart := cloudFraction * about(cloudAlbedo, 0.2)
	var rockPart float64
	if surfacePressure == 0.0 {
		rockPart = rockFraction * about(rockyAirlessAlbedo, 0.3)
	} else {
		rockPart = rockFraction * about(rockyAlbedo, 0.1)
	}
	waterPart := waterFraction * about(waterAlbedo, 0.2)
	var icePart float64
	if surfacePressure == 0.0 {
		icePart = iceFraction * about(iceAirlessAlbedo, 0.4)
	} else {
		icePart = iceFraction * about(iceAlbedo, 0.1)
	}
	return cloudPart + rockPart + waterPart + icePart
}

//   This function returns the dimensionless quantity of optical depth,
//   which is useful in determining the amount of greenhouse effect on a
//   planet.
func opacity(molecularWeight, surfacePressure float64) float64 {
	opticalDepth := 0.0
	switch {
	case molecularWeight >= 0.0 && molecularWeight < 10.0:
		opticalDepth += 3.0
	case molecularWeight < 20.0:
		opticalDepth += 2.34
	case molecularWeight < 30.0:
		opticalDepth += 1.0
	case molecularWeight < 45.0:
		opticalDepth += 0.15
	case molecularWeight < 100.0:
		opticalDepth += 0.05
	}
	switch {
	case surfacePressure >= 70.0*earthSurfacePressureInMillibars:
		opticalDepth *= 8.333
	case surfacePressure >= 50.0*earthSurfacePressureInMillibars:
		opticalDepth *= 6.666
	case surfacePressure >= 30.0*earthSurfacePressureInMillibars:
		opticalDepth *= 3.333
	case surfacePressure >= 10.0*earthSurfacePressureInMillibars:
		opticalDepth *= 2.0
	case surfacePressure >= 5.0*earthSurfacePressureInMillibars:
		opticalDepth *= 1.5
	}
	return opticalDepth
}

//   The temperature calculated is in degrees Kelvin.
//   Quantities already known which are used in these calculations:
//	 p.molec_weight
//	 p.surf_pressure
//	 sys.r_ecosphere
//	 p.a
//	 p.volatile_gas_inventory
//	 p.radius
//	 p.boil_point
func (sys *System) iterateSurfaceTemp(p *Planet) {
	var albedo, water, clouds, ice float64

	opticalDepth := opacity(p.molecularWeight, p.surfacePressure)
	effTemp := effectiveTemp(sys.r_ecosphere, p.a, earthAlbedo)
	greenhsRise := greenhouseRise(opticalDepth, effTemp, p.surfacePressure)
	surfaceTemp := effTemp + greenhsRise
	prevTemp := surfaceTemp - 5.0 // force the loop the first time
	for abs(surfaceTemp-prevTemp) > 1.0 {
		prevTemp = surfaceTemp
		water = hydroFraction(p.volatileGasInventory, p.radius)
		clouds = cloudFraction(surfaceTemp, p.molecularWeight, p.radius, water)
		ice = iceFraction(water, surfaceTemp)
		if surfaceTemp >= p.boilingPoint || surfaceTemp <= freezingPointOfWater {
			water = 0.0
		}
		albedo = planetAlbedo(water, clouds, ice, p.surfacePressure)
		opticalDepth = opacity(p.molecularWeight, p.surfacePressure)
		effTemp = effectiveTemp(sys.r_ecosphere, p.a, albedo)
		greenhsRise = greenhouseRise(opticalDepth, effTemp, p.surfacePressure)
		surfaceTemp = effTemp + greenhsRise
	}
	p.hydrosphere = water
	p.cloudCover = clouds
	p.iceCover = ice
	p.albedo = albedo
	p.surfaceTemp = surfaceTemp
}
