package accrete

// Planet represents an individual planet.
//
// TODO(x): export some fields and/or provide accessor methods.
type Planet struct {
	a                    float64 // semi-major axis of the orbit (in AU)
	e                    float64 // eccentricity of the orbit
	mass                 float64 // mass (in solar masses)
	gasGiant             bool    // is the planet a gas giant
	radius               float64 // equatorial radius (in km)
	density              float64 // density (in g/cc)
	orbitalPeriod        float64 // length of the local year (days)
	day                  float64 // length of the local day (hours)
	resonantPeriod       bool    // is the planet in resonant rotation
	axialTilt            int     // units of degrees
	escapeVelocity       float64 // units of cm/sec
	surfaceAcceleration  float64 // units of cm/sec2
	surfaceGravity       float64 // units of Earth gravities
	rmsVelocity          float64 // units of cm/sec
	molecularWeight      float64 // smallest molecular weight retained
	volatileGasInventory float64 //
	surfacePressure      float64 // units of millibars (mb)
	greenhouseEffect     bool    // runaway greenhouse effect?
	boilingPoint         float64 // the boiling point of water (Kelvin)
	albedo               float64 // albedo of the planet
	surfaceTemp          float64 // surface temperature in Kelvin
	hydrosphere          float64 // fraction of surface covered
	cloudCover           float64 // fraction of surface covered
	iceCover             float64 // fraction of surface covered
}

type dust struct {
	innerEdge   float64
	outerEdge   float64
	dustPresent bool
	gasPresent  bool
}
